# Inventaires (métadonnées uniquement)

Générés par `tools/inventory.py` à partir d'une installation locale. Aucun contenu de jeu :
uniquement des noms, tailles et catégories.

## `bundles-inventory.csv`

| Colonne | Description |
|---|---|
| `source` | `aa`, `licensed-core`, `licensed-extra` |
| `bundle` | Nom du fichier `.bundle` |
| `family` | Famille déduite (`ui`, `shaders`, `kits3d`, `club`, …) |
| `size_mb` | Taille en Mo |

554 lignes : 293 `aa` (3 852 Mo) + 188 `licensed-core` (600 Mo) + 73 `licensed-extra`
(29 Mo).

## `licensed-coverage.csv`

| Colonne | Description |
|---|---|
| `category` | `club`, `comp`, `kits2d`, `kits3d`, `players`, `flag`, `pitchflags` |
| `code` | Code pays/région (`eng`, `fra`, `jpn`, `eur`, …) |
| `variant` | `w` = féminine, `nl` = National League, vide sinon |
| `bundle_count` | Nombre de bundles |
| `total_mb` | Taille cumulée |

201 lignes. `default`, `fmfc`, `goalkeeper`, `numbers`, `nations` sont des ressources
génériques, pas des pays.

## `db-files.csv`

| Colonne | Description |
|---|---|
| `relative_path` | Chemin relatif à `db/2620` |
| `name` | Nom du fichier |
| `extension` | `.dat`, `.dbc`, `.lnc`, `.edt`, `.ddt`, `.xml` |
| `size_mb` | Taille |
| `role` | Rôle déduit |

99 lignes.

## Régénération

```powershell
python tools/inventory.py "D:\Games\Football Manager 26" --out data
```

Le script ne lit jamais le contenu des fichiers.
