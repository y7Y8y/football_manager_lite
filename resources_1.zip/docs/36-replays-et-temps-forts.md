# 36 — Replays et temps forts

## Objectif

Revoir les actions importantes sans rejouer tout le match.

## Modes de diffusion

| Mode | Contenu |
|---|---|
| Match complet | tous les événements |
| Moments clés | buts, cartons, occasions |
| Résumé étendu | plus de phases |
| Résultat instantané | simulation sans rendu |

## Buffer de replay

- Conserver les N dernières secondes d'état.
- Snapshot à intervalles réguliers.
- Rejouer avec interpolation.
- Caméra indépendante du direct.

```
ring_buffer[secondes] → snapshot → replay
```

## Moments clés

Un événement est « clé » selon :

- type (but, carton rouge, penalty) ;
- xG du tir ;
- score et minute ;
- rivalité ;
- consigne utilisateur.

## Caméras de replay

- TV.
- Derrière le but.
- Ralenti.
- Vue tactique.
- Libre.

## Contrôles

- Lecture / pause.
- Vitesse (0.25× à 2×).
- Avance / recul.
- Changement de caméra.
- Quitter.

## Modèle de données

```
highlights(id, match_id, event_id, start_time, end_time, camera, priority)
replay_buffer(match_id, timestamp, state_blob)
```

## MVP

1. Replay du dernier but.
2. Caméra TV + ralenti.
3. Contrôles lecture/pause.
4. Puis buffer complet, caméras multiples, partage.

## Performance

- Le replay ne doit pas relancer la simulation.
- Stocker l'état, pas les décisions.
- Compresser les snapshots.
- Limiter la durée du buffer.

## Approfondissement

### Taille du buffer

```text
buffer = 30 s * frequence_snapshot
```

- Snapshot toutes les 500 ms.
- 60 snapshots = 30 s.
- Compresser chaque snapshot.

### Priorité des moments

```text
priorite = type * 10 + xg * 5 + minute / 10
```

### Cas limites

- But à la 90e → buffer conservé.
- Replay pendant le direct → pause.
- Mémoire insuffisante → réduire le buffer.

### Critères de test

- Le replay est fluide.
- Le score ne change pas.
- Le buffer ne fuit pas.
