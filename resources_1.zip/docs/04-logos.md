# 04 — Logos et écussons

## Où sont les logos

1. **Contenu sous licence** : `fm_Data\StreamingAssets\LicensedData\{Core,Extra}`
   - `club-<pays>` : écussons de clubs
   - `comp-<pays>` : logos de compétitions
   - `flag-<région>` : drapeaux
   - `pitchflags-<région>` : drapeaux sur la pelouse
   - `continents` : confédérations
2. **Visuels génériques** : bundles `*_default`.

Aucun dossier `graphics` n'est livré : les packs communautaires sont externes.

## Volumétrie

| Catégorie | Bundles | Taille |
|---|---|---|
| `club-*` | 36 (dont `default`, `fmfc`, `lva`) | 36,7 Mo |
| `comp-*` | 38 (dont `default`, `eur`, `lat`, `lva`) | 3,0 Mo |
| `flag-*` / `pitchflags-*` | 14 | 1,8 Mo |
| `kits2d-*` | 70 | 49,5 Mo |
| `kits3d-*` | 64 | 115,7 Mo |
| `players-*` | 33 | 415,8 Mo |
| Total `LicensedData` | 261 | 629 Mo (dont ~6,5 Mo de catalogues) |

## Couverture par pays (écussons)

| Zone | Pays |
|---|---|
| Amérique du Sud | Argentine |
| Océanie | Australie (+ féminine) |
| Europe | Belgique, Croatie, Tchéquie, Danemark (+F), Angleterre (+F), France, Allemagne (+F), Gibraltar, Italie (+F), Lettonie, Lituanie, Pays-Bas, Irlande du Nord, Pologne, Portugal, Écosse, Suède (F), Pays de Galles (+F) |
| Amérique du Nord | Canada, Mexique, États-Unis (+F) |
| Asie | Japon (+F), Corée du Sud, Émirats arabes unis |

**Non couverts** (génériques) : Espagne, Brésil, Turquie, Russie, Ukraine, Grèce, Suisse,
Autriche, Norvège, Suède masculine, Irlande, Islande, Finlande, Roumanie, Serbie, Hongrie,
Bulgarie.

> Même avec le jeu officiel, un club espagnol ou brésilien s'affiche avec un écusson
> générique sans pack externe.

## Compétitions

`comp-*` couvre les mêmes pays, plus :

- `comp-eur` : compétitions européennes
- `comp-lva`, `comp-lat` : Baltes / Amérique latine
- `comp-default` : générique

`Extra` ajoute des compétitions (Belgique, Danemark, Angleterre, Lettonie, Pays-Bas,
Irlande du Nord, Écosse, Amérique latine) mais **pas d'écussons de clubs**.

## Format

- Bundles Unity (`UnityFS`, Unity 6) ; les images sont **dans** les `.bundle`.
- Chargement par **UID**, pas par nom de fichier.
- Visuels 2D uniquement (pas de logo 3D).

## Surcharge utilisateur

```
Documents\Sports Interactive\Football Manager 26\graphics\logos\
└─ <pack>\
   ├─ config.xml
   └─ *.png
```

Principe :

1. Chaque image est associée à l'UID dans `config.xml`.
2. Chargement au démarrage ou via **Préférences → Interface → Recharger le skin**.
3. Le pack utilisateur prime sur le jeu (doc 07).

Exemple :

```xml
<record>
  <list id="maps">
    <record from="club_uid" to="graphics/pictures/club/uid/logo"/>
  </list>
</record>
```

## Bonnes pratiques

- Un pack = un dossier = un `config.xml`.
- Respecter les UID.
- Recharger le skin après ajout.
- Résolution courante : 180×180 ou 512×512.

## Légalité

Les logos sont des marques. Les packs tiers relèvent de leurs auteurs. Ce dépôt ne contient
aucune image ni lien.

## Approfondissement

### Résolution d'un logo

```text
fonction logo(club_uid):
    si pack_utilisateur contient club_uid: retourner pack_utilisateur[club_uid]
    si bundle club-<pays> contient club_uid: retourner bundle[club_uid]
    si bundle club-default contient club_uid: retourner bundle[club_uid]
    retourner placeholder
```

### Validation d'un pack

- `config.xml` lisible et bien formé.
- Chaque `from` correspond à un fichier existant.
- Chaque `to` respecte le format `graphics/pictures/club/<uid>/logo`.
- Pas de doublon d'UID.
- Images carrées, taille minimale 180×180.

### Cache

- Résoudre une fois par session.
- Invalider au rechargement du skin.
- Ne pas garder les textures 4K en mémoire si non affichées.

### Cas limites

- Deux packs avec le même UID → dernier chargé gagnant (hypothèse).
- Logo transparent → prévoir un fond.
- UID inexistant → fallback générique.

### Critères de test

- Un pack de 500 logos s'affiche sans ralentissement.
- Un `config.xml` invalide n'empêche pas le jeu de démarrer.
- Le fallback fonctionne pour un club non licencié.
