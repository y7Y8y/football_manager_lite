# 23 — Blessures et médical

## Objectif

Gérer l'usure, les blessures, la récupération et le retour.

## Modèle de blessure

| Champ | Exemple |
|---|---|
| Type | muscle, ligament, fracture, commotion |
| Gravité | légère, moyenne, grave |
| Durée | jours à mois |
| Récidive | risque |
| Contexte | match, entraînement, hors club |

## Causes

- Charge d'entraînement élevée.
- Enchaînement des matchs.
- Condition physique basse.
- Âge.
- Contact (tacle).
- Terrain/météo.
- Récidive mal soignée.

## Prévention

| Moyen | Effet |
|---|---|
| Rotation | réduit la fatigue |
| Intensité modérée | réduit le risque |
| Staff médical | accélère le retour |
| Installations | réduit la gravité |
| Repos | récupération |

## Événements

`injury`, `diagnosis`, `treatment_start`, `return_to_training`, `return_to_match`,
`setback`.

## Récupération

```
durée = base(gravité) * facteur_staff * facteur_installations * facteur_age
```

Le joueur revient avec une condition physique partielle et un risque de rechute.

## Modèle de données

```
injuries(id, player_id, type, severity, start_date, expected_return, actual_return, context)
medical_staff(id, club_id, name, skill)
player_condition(player_id, fitness, sharpness, fatigue)
```

## MVP

1. Fatigue liée aux matchs.
2. Blessures aléatoires pondérées.
3. Durée de retour.
4. Condition physique au retour.
5. Puis récidives, staff, installations.

## Bonnes pratiques

- Ne pas blesser un joueur sans cause lisible.
- Afficher la cause et la durée.
- Éviter les blessures en cascade injustes.
- Laisser le joueur gérer la rotation.

## Approfondissement

### Probabilité par match

```text
risque = base * fatigue * intensite * age * terrain
risque = clamp(risque, 0, 0.15)
```

### Récupération

```text
jours = base_gravite * facteur_staff * facteur_installations
```

| Gravité | Base |
|---|---|
| Légère | 3–7 jours |
| Moyenne | 2–6 semaines |
| Grave | 2–9 mois |

### Cas limites

- Blessure en sélection nationale.
- Rechute avant le retour.
- Blessure lors d'un prêt.
- Commotion → protocole obligatoire.

### Critères de test

- Une blessure a toujours une cause affichée.
- Le retour respecte la durée annoncée.
- La condition physique remonte progressivement.
