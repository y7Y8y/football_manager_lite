# 29 — Rendu et shaders

## Objectif

Obtenir une image stable, lisible et performante, sans sacrifier la simulation.

## Pipeline

| Étape | Rôle |
|---|---|
| Culling | ne dessiner que le visible |
| Opaque | terrain, joueurs, stade |
| Transparent | vitres, filets, particules |
| Ombres | directionnelle + bakée |
| Post-traitement | bloom, DOF, motion blur, AA |
| UI | overlay séparé |

Sur Unity : **URP** (Universal Render Pipeline). Sur Godot : Forward+. Sur Unreal : Lumen
optionnel.

## Éclairage

- Lumière directionnelle (soleil).
- Lumière ambiante / ciel.
- Ombres bakées pour le stade.
- Ombres dynamiques pour les joueurs.
- Sondes de lumière pour l'ambiance.
- Heure du jour et météo.

## Matériaux

| Type | Particularité |
|---|---|
| Terrain | herbe, lignes, usure |
| Peau | subsurface scattering |
| Cheveux | anisotropic |
| Maillot | tissu, sponsors |
| Ballon | reflets, motifs |
| Métal | poteaux, barrières |

## Textures

- Atlas pour les petits éléments.
- Mipmaps.
- Compression (BC7/ASTC).
- Streaming pour les gros bundles.
- Résolution adaptée à la distance.

## LOD et culling

- 3 niveaux par personnage.
- Distance + taille à l'écran.
- Occlusion culling.
- Frustum culling.
- Désactiver les animations lointaines.

## Batching

- GPU instancing pour la foule et les sièges.
- Static batching pour le stade.
- SRP Batcher (Unity URP) pour les matériaux compatibles.
- Éviter les changements de matériau par draw call.

## Post-traitement

| Effet | Attention |
|---|---|
| Bloom | lisibilité |
| DOF | couteux |
| Motion blur | nausée |
| AA | TAA vs MSAA |
| Color grading | cohérence |

## Budgets

| Cible | Valeur |
|---|---|
| FPS | 60 |
| Draw calls | < 1 500 |
| Triangles visibles | < 2 M |
| Textures | streaming |
| Ombres | 1 cascade proche |

## Référence FM26 (observée)

Unity 6 + URP, shaders `LuxURP Hair` / `LuxURP Skin`, 59 bundles de shaders, 47 ciels,
post-traitement bloom/DOF/motion blur.

## MVP

1. Terrain + ciel + lumière.
2. Ombres bakées.
3. LOD joueurs.
4. Foule instanciée.
5. Puis post-traitement et météo.

## Approfondissement

### Budget détaillé

| Poste | 1080p | 4K |
|---|---|---|
| Opaque | 6 ms | 10 ms |
| Transparent | 2 ms | 4 ms |
| Ombres | 3 ms | 5 ms |
| Post | 2 ms | 4 ms |
| UI | 2 ms | 2 ms |

### Variantes de shader

- Éviter les variantes inutiles.
- Compiler à la construction.
- Tester sur GPU bas de gamme.

### Culling

```text
si hors frustum: ignorer
si occulté: ignorer
sinon: dessiner
```

### Critères de test

- 60 fps en 1080p.
- Pas de frame > 33 ms.
- Aucun shader rose (erreur).
