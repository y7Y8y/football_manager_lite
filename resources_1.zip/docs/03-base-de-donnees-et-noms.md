# 03 — Base de données et noms

## Emplacement

```
shared/data/database/db/
├─ 2300/ … 2430/     anciennes versions (non utilisées par FM26)
├─ 2600/             FM26.0
└─ 2620/             FM26.2  ← utilisée
   ├─ 2620_fm/       données principales
   ├─ dbc/           configurations et correctifs
   ├─ edt/           règles d'éditeur
   └─ lnc/           remplacements de noms
```

## Fichiers principaux (`2620_fm`)

| Fichier | Taille | Rôle |
|---|---|---|
| `people_db.dat` | 73,0 Mo | Joueurs et staff |
| `basic_people_db.dat` | 12,2 Mo | Personnes hors effectif actif |
| `server_db.dat` | 65,6 Mo | Clubs, compétitions, structures |
| `client_db.dat` | 14,5 Mo | Données côté client |
| `pl_hist_dt.dat` | 98,2 Mo | Historiques joueurs |
| `pl_hist_index.dat` | 6,0 Mo | Index |
| `pl_hist_id.dat` | 3,8 Mo | Identifiants |
| `non_pl_hist_dt.dat` | 38,2 Mo | Historiques non-joueurs |
| `non_pl_hist_index.dat` | 11,0 Mo | Index |
| `non_pl_hist_id.dat` | 3,7 Mo | Identifiants |
| `summary.dat` | 5,0 Mo | Résumé |
| `lang_update_db.dat` | 84,4 Mo | Libellés |

## Format observé

Conteneur propriétaire + flux **LZ4** :

```
people_db.dat : 03 01 74 61 64 2E A0 0F 90 0E 07 00 | 28 B5 2F FD ...
                ^^ ^^ "t a d ."  (en-tête)            ^^ magic LZ4
```

Archives `.fmf` :

```
simatch.fmf : 02 01 66 6D 66 2E 08 00 00 3E 34 14 00 ... (28 B5 2F FD)
              ^^ ^^ "f m f ."   taille
```

Aucune API publique : le format n'est pas destiné à être lu hors du jeu ou de l'éditeur.

## D'où viennent les noms

1. **Base principale** : nom, prénom, naissance, nationalité, club, attributs.
2. **`.dbc`** : correctifs de base (licences, noms fictifs, compétitions).
3. **`.lnc`** : tables de remplacement de texte.
4. **`.edt` / `.ddt`** : règles et données d'éditeur.

### Exemples `.dbc`

| Fichier | Rôle apparent |
|---|---|
| `licensing26.dbc` | Licences de la saison |
| `Licensing2.dbc`, `Licensing2_chn.dbc` | Licences complémentaires / Chine |
| `japan_unlicensed_random_names.dbc` | Noms aléatoires Japon non licencié |
| `japan_fake.dbc` | Noms fictifs Japon |
| `forbidden names.dbc`, `swear_words.dbc` | Filtres |
| `create a club.dbc` | Mode création de club |
| `wc_kits.dbc` | Maillots Coupe du monde |
| `brazil_kits.dbc` | Maillots Brésil |

### Exemples `.lnc`

| Fichier | Rôle apparent |
|---|---|
| `acmilan unlic 24.lnc` | Noms réels de clubs non licenciés |
| `japanese names.lnc` | Noms japonais réels |
| `greek team names.lnc` | Noms grecs |
| `chinese team names.lnc` | Noms chinois |
| `fake.lnc` | Neutralisation |
| `stage names.lnc` | Noms de phases |
| `world cup comp.lnc` | Noms de compétitions |

Un `.lnc` est un fichier de correspondances appliqué au chargement.

## Éditeur

- `editor.fmf` = ressources, pas l'application.
- L'éditeur complet est un outil séparé.
- Les modifications vont dans `Documents\Sports Interactive\Football Manager 26\editor data\`.

## Nombre de joueurs

Le nombre réel dépend de la base livrée, des **ligues chargées** et des options avancées. Le
compteur officiel est affiché à l'écran de configuration de la base.

## Intégrité

- `people_db.dat` 73,0 Mo (FM26.2) contre 72,1 Mo (FM26.0).
- Bases 2300–2430 : 64–69 Mo (anciennes générations).
- Aucun fichier tronqué détecté.

## À ne pas faire

- Redistribuer les `.dat`, `.dbc`, `.lnc`, `.edt`.
- Modifier la base pendant qu'une partie est ouverte.

## Approfondissement

### Structure du conteneur

```text
[0x03][0x01]["tad."][version 2 octets][taille 4 octets][flags]
[bloc LZ4 frame : 28 B5 2F FD ...]
```

- Le flux LZ4 contient des blocs compressés indépendants.
- Les index (`*_index.dat`) accélèrent la recherche par identifiant.
- Les fichiers `*_id.dat` font la correspondance entre identifiants.

### Contrôles d'intégrité

1. Vérifier la signature (`03 01 74 61 64 2E`).
2. Vérifier la présence du magic LZ4.
3. Comparer la taille attendue à la taille réelle.
4. Vérifier que les fichiers d'index correspondent aux données.

### Stratégie de lecture

- Ne jamais charger toute la base en mémoire pour une seule fiche.
- Utiliser les index pour les recherches par ID.
- Mettre en cache les entités consultées.
- Séparer lecture (jeu) et écriture (éditeur).

### Cas limites

- Base modifiée pendant une partie ouverte → corruption.
- Version de base différente de la version du jeu → refus.
- Fichier `.lnc` mal encodé → noms corrompus.

### Critères de test

- Ouvrir une fiche joueur sans charger 73 Mo.
- Rechercher un ID en moins de 10 ms.
- Détecter un fichier tronqué avant de l'utiliser.
