# 47 — Télémétrie et équilibrage

## Objectif

Comprendre comment le jeu est joué et corriger les déséquilibres.

## Principes

- **Opt-in** et anonyme.
- Pas de données personnelles.
- Pas de contenu de sauvegarde.
- Documenté dans la politique de confidentialité.

## Événements à mesurer

| Événement | Utilité |
|---|---|
| Démarrage | stabilité |
| Match terminé | durée, score |
| Transfert | prix, fréquence |
| Blessure | taux |
| Abandon | point de friction |
| Crash | stabilité |

## Indicateurs

- Taux de victoire par formation.
- Buts par match.
- Transferts par saison.
- Taux de blessure.
- Temps de session.
- Taux de complétion du tutoriel.

## Boucle d'équilibrage

```text
collecter → analyser → hypothèse → ajuster → tester → déployer
```

- Une modification à la fois.
- Comparer avant/après.
- Éviter les ajustements sur peu de données.

## Modèle de données

```
telemetry_events(id, user_hash, event_type, payload_json, created_at)
balance_snapshots(id, version, metric, value, sample_size)
```

## MVP

1. 5 événements.
2. Tableau de bord simple.
3. Aucune donnée personnelle.
4. Puis A/B testing.

## Critères de test

- L'opt-out est respecté.
- Aucune donnée sensible collectée.
- Les métriques sont reproductibles.
