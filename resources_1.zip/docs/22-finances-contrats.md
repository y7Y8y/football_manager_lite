# 22 — Finances et contrats

## Revenus

| Source | Variation |
|---|---|
| Droits TV | selon compétition et classement |
| Billetterie | affluence × prix |
| Commercial | réputation, sponsors |
| Primes | coupes, classement |
| Transferts | ventes |

## Dépenses

| Poste | Détail |
|---|---|
| Salaires | joueurs + staff |
| Transferts | indemnités + commissions |
| Fonctionnement | stade, déplacements |
| Formation | académie |
| Installations | améliorations |
| Prêts | intérêts |

## Budgets

- **Budget transfert** : disponible pour les indemnités.
- **Masse salariale** : plafond hebdomadaire/annuel.
- **Budget staff**.
- **Budget académie**.

Un dépassement de masse salariale bloque les recrutements ou déclenche une sanction.

## Fair-play financier

Règle simplifiée pour un jeu :

```
pertes_autorisées = f(revenus, saison, propriétaire)
si pertes > seuil → sanctions (interdiction de recrutement, amende, exclusion)
```

## Contrats

| Élément | Détail |
|---|---|
| Durée | 1 à 5 ans |
| Salaire | hebdomadaire ou annuel |
| Primes | apparition, buts, titre |
| Clause libératoire | montant fixe |
| Option | année supplémentaire |
| Prime d'agent | % ou forfait |
| Indemnité de signature | one-shot |

### Fin de contrat

- À 6 mois de la fin : possibilité de pré-contrat (Bosman).
- À l'expiration : joueur libre.
- Option club : prolongation automatique si activée.

## Modèle de données

```
club_finances(club_id, season, revenue, costs, transfer_budget, wage_budget)
transactions(id, club_id, date, type, amount, description)
contracts(id, player_id, club_id, start, end, wage, bonuses, release_clause, option_year)
sponsors(id, club_id, name, amount, start, end)
```

## MVP

1. Revenus fixes + billetterie.
2. Salaires.
3. Budget transfert.
4. Contrats avec durée et salaire.
5. Puis FFP, sponsors, installations.

## Équilibrage

- Un club ne doit pas devenir riche en une saison.
- Les salaires doivent peser plus que les transferts.
- Les petits clubs doivent survivre par la formation et les ventes.

## Approfondissement

### Grand livre

```text
solde = solde + revenus - depenses
si solde < 0: alerte
si solde < -seuil: sanction
```

### Vérification d'un transfert

```text
si indemnite > budget_transfert: refus
si salaire > budget_salaire: refus
si masse_salariale + salaire > plafond: refus
```

### Contrats

- Date de fin.
- Option de prolongation.
- Clause libératoire.
- Primes conditionnelles.
- Indemnité de signature.

### Critères de test

- Aucun club ne peut dépenser au-delà de son budget.
- Les salaires sont payés chaque semaine.
- Un contrat expiré libère le joueur.
