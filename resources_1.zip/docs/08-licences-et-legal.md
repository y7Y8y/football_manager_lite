# 08 — Licences et cadre légal

## Objet

Documentation technique personnelle : structure, rôles, tailles, schémas. **Aucun fichier du
jeu** n'est inclus.

## Autorisé

- Décrire l'architecture et les formats de haut niveau.
- Lister noms de fichiers, tailles, catégories.
- Écrire des scripts qui lisent uniquement des **métadonnées**.
- Citer de courts extraits de configuration.
- Comparer des versions.

## Interdit

| Interdit | Pourquoi |
|---|---|
| Copier `.bundle`, `.dat`, `.dbc`, `.lnc`, `.fmf` | données/assets propriétaires |
| Publier logos, maillots, photos, modèles | droit d'auteur, marques, image |
| Liens de téléchargement du jeu ou de packs | contrefaçon |
| Documenter un contournement de protection | illégal dans de nombreux pays |
| Héberger le jeu sur GitHub | CGU + droit d'auteur |

## Statut du jeu

FM26, ses bases, ses assets et son moteur appartiennent à Sports Interactive / Sega.
Documenter la structure ne transfère aucun droit sur les fichiers.

## Packs communautaires

Distribués par des sites tiers ; ils contiennent des marques et images de tiers. Leur
installation relève de l'utilisateur.

## GitHub

- 25 Mo par fichier via le web, 100 Mo via git/API
- dépôt recommandé < 1 Go
- DMCA possible, suspension de compte

Un dépôt de documentation + CSV + script pèse moins de 1 Mo.

## Checklist avant publication

- [ ] Aucun `.bundle`, `.dat`, `.dbc`, `.lnc`, `.fmf`, `.dll`, `.exe`
- [ ] Aucune image, logo, maillot, photo
- [ ] Aucun lien de téléchargement
- [ ] Aucune mention de crack/hyperviseur
- [ ] Mention « non affilié à SI/Sega »
- [ ] Licence explicite

## Licence du dépôt

- Code (`tools/`) : MIT — voir `LICENSE`.
- Documentation (`docs/`, `README.md`) : CC BY 4.0.

Ces licences ne couvrent que le contenu original du dépôt.

## Approfondissement

### Arbre de décision

```text
Le contenu vient-il de FM ?
  oui → ne pas redistribuer
  non → a-t-il une licence écrite ?
          oui → vérifier le périmètre (usage, territoire, durée)
          non → utiliser un placeholder ou une source libre
```

### Périmètre d'une licence

- Support (jeu, site, démo).
- Territoire.
- Durée.
- Usage commercial ou non.
- Modification autorisée ou non.
- Redistribution à des sous-traitants.

### Checklist de publication

- [ ] Origine de chaque asset tracée
- [ ] `licenses.csv` complet
- [ ] Aucun fichier FM
- [ ] Aucune capture de FM
- [ ] Mention « non affilié »
- [ ] Procédure de retrait

### Critères de test

- Un script vérifie l'absence d'extensions interdites.
- Un humain vérifie les images.
