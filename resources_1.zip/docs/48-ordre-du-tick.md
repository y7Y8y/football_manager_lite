# 48 — Ordre du tick

## Objectif

Définir l'ordre exact des systèmes à chaque pas de simulation, pour garantir le déterminisme
et éviter les dépendances circulaires.

## Principe

Un tick est une **transaction** : on lit un état, on applique des systèmes dans un ordre
fixe, on produit un nouvel état.

```
état(t) → systèmes ordonnés → état(t+1) + événements
```

## Ordre recommandé

| # | Système | Produit |
|---|---|---|
| 1 | Horloge | minute, temps additionnel |
| 2 | Calendrier | matchs du jour |
| 3 | IA des clubs | décisions de transfert, effectif |
| 4 | Contrats | expirations, renouvellements |
| 5 | Entraînement | progression, fatigue |
| 6 | Médical | blessures, retours |
| 7 | Tactique | familiarité, consignes |
| 8 | Préparation | compositions |
| 9 | Match (simulation) | événements, score |
| 10 | Statistiques | agrégation |
| 11 | Presse | questions, effets |
| 12 | Moral | mise à jour |
| 13 | Finances | salaires, revenus |
| 14 | Sauvegarde | snapshot |

## Tick de match

```
perception → décisions → déplacements → collisions → ballon → événements
```

- Les décisions sont prises **avant** les déplacements.
- Les collisions sont résolues après les déplacements.
- Le ballon est mis à jour en dernier.
- Les événements sont émis après stabilisation.

## Déterminisme

- Aucun accès au temps réel.
- Aucune itération sur un dictionnaire non ordonné.
- Aucun aléatoire non seedé.
- Même ordre sur toutes les machines.

## Budget

| Système | Budget |
|---|---|
| Match | 4 ms |
| IA clubs | 1 ms |
| Reste | 2 ms |

## Cas limites

- Deux événements au même tick → ordre par `sequence`.
- Système lent → dégradation, pas de saut.
- Pause → aucun tick.

## Critères de test

- Même graine = même état final.
- Aucun système ne dépend d'un système postérieur.
- Le tick reste sous le budget.
