# 39 — Éditeur et modding

## Objectif

Permettre de créer des données, des ligues et du contenu sans toucher au code.

## Éditeur de données

| Fonction | Détail |
|---|---|
| Clubs | nom, ville, stade, couleurs |
| Joueurs | identité, attributs, contrat |
| Compétitions | format, règles, calendrier |
| Staff | rôles, attributs |
| Stades | capacité, nom |
| Maillots | couleurs, motifs |

### Import / export

- CSV pour les gros volumes.
- JSON pour les structures.
- Validation avant import.
- Rapport d'erreurs lisible.

## Règles de validation

- Champs obligatoires.
- Valeurs dans les bornes.
- Références existantes (club, pays).
- Doublons.
- Calendrier cohérent.

## Modding

| Niveau | Contenu |
|---|---|
| Données | ligues, joueurs, clubs |
| Graphismes | logos, maillots, visages |
| Interface | thèmes, skins |
| Code | plugins (option) |

### API de modding (option)

- Événements exposés.
- Hooks avant/après match.
- Accès en lecture aux données.
- Pas d'accès aux fonctions réseau.

## Sécurité

- Sandbox des plugins.
- Pas d'exécution arbitraire.
- Validation des assets.
- Signature des mods (option).

## Modèle de données

```
mods(id, name, version, author, enabled)
mod_files(mod_id, path, checksum)
import_jobs(id, type, status, errors)
```

## MVP

1. Export CSV des joueurs/clubs.
2. Import avec validation.
3. Éditeur de ligue simple.
4. Puis graphismes, plugins, atelier.

## Légalité

Les mods ne doivent pas redistribuer d'assets propriétaires. Voir
[10](10-donnees-et-licences.md).

## Approfondissement

### Pipeline d'import

```text
fichier → parse → validation → dry-run → import → rapport
```

### Règles de validation

- Champs obligatoires.
- Références existantes.
- Valeurs bornées.
- Doublons.

### Cas limites

- Import partiel.
- Conflit d'identifiants.
- Mod incompatible avec la version.

### Critères de test

- Un import invalide ne modifie rien.
- Le rapport liste chaque erreur.
- Un mod se désactive sans casser la sauvegarde.
