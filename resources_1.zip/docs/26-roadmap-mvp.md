# 26 — Roadmap MVP

## Objectif

Construire un jeu jouable par étapes, sans dépendre des assets réels.

## Phase 0 — Cadrage (1 à 3 jours)

- Choisir le moteur (Unity, Godot, web).
- Définir le périmètre : ligue unique, 2 saisons, pas de 3D au début.
- Décider : données fictives, pas d'assets FM.
- Poser le schéma de données ([25](25-modele-de-donnees.md)).

**Critère de sortie** : un dépôt qui démarre, une base vide, un README.

## Phase 1 — Données (3 à 7 jours)

- Générateur de données fictives : pays, ligue, 10–20 clubs, 400–600 joueurs.
- Staff minimal.
- Calendrier aller-retour.
- Chargement en mémoire + sauvegarde.

**Critère** : afficher un club et son effectif.

## Phase 2 — Simulation texte (1 à 2 semaines)

- Match tick par tick, sans rendu.
- Buts, cartons, blessures, fin de match.
- Logs lisibles.
- Classement calculé.

**Critère** : simuler une saison complète sans interface.

## Phase 3 — Interface (1 à 2 semaines)

- Écrans : club, effectif, tactique, calendrier, classement, transferts.
- Navigation clavier/souris.
- Sauvegarde/chargement.

**Critère** : jouer une saison uniquement via l'UI.

## Phase 4 — Match 2D (1 à 2 semaines)

- Terrain, 22 points, ballon.
- Caméra, vitesse, pause.
- Événements affichés.
- Statistiques.

**Critère** : regarder un match en 2D et comprendre ce qui se passe.

## Phase 5 — Match 3D (3 à 6 semaines)

- Terrain 3D + 22 personnages + ballon.
- Animations de course et d'action.
- Caméra TV.
- Stade simple + foule en sprites.

**Critère** : match 3D fluide à 60 fps sur une machine moyenne.

## Phase 6 — Profondeur (en continu)

- Transferts avancés, prêts, clauses.
- Presse, moral, conseil.
- Académie, scouting.
- Finances, FFP.
- Rivalités, supporters.
- Replays, commentaires.

## Priorités

| Priorité | Systèmes |
|---|---|
| P0 | données, simulation, classement, UI |
| P1 | transferts, tactique, blessures, finances |
| P2 | presse, jeunes, scouting, rivalités |
| P3 | 3D avancée, cinématiques, audio |

## Définition de « jouable »

- On peut créer une partie.
- On peut choisir un club.
- On peut jouer un match.
- On peut faire un transfert.
- On peut sauvegarder et recharger.

## Définition de « démo publiable »

- 2 saisons complètes.
- 10 clubs fictifs.
- Logos et visages générés.
- Aucun asset de tiers.
- Licence claire.

## Risques

| Risque | Parade |
|---|---|
| Trop de fonctionnalités | P0 d'abord, P2 plus tard |
| 3D trop tôt | 2D d'abord, 3D après la boucle |
| Données réelles | base fictive au départ |
| Formules copiées | concevoir et tester les siennes |
| Sauvegarde cassée | versionner le format |

## Approfondissement

### Critères d'acceptation par phase

| Phase | Critère |
|---|---|
| 0 | Le projet démarre et se documente |
| 1 | Un club et son effectif s'affichent |
| 2 | Une saison se simule sans UI |
| 3 | Une saison se joue via l'UI |
| 4 | Un match 2D est compréhensible |
| 5 | Un match 3D tient 60 fps |
| 6 | Les systèmes P1 sont stables |

### Indicateurs

- Temps de simulation d'une saison.
- Nombre de crashs par heure.
- Temps de chargement d'une sauvegarde.
- Taux de transferts réussis.

### Risques et parades

| Risque | Parade |
|---|---|
| Scope creep | backlog strict P0 |
| 3D trop tôt | 2D d'abord |
| Données réelles | base fictive |
| Sauvegarde instable | versionner tôt |

### Critères de test

- Chaque phase se termine par une démo.
- Aucun système P0 ne dépend d'un système P2.
