# 30 — Cartons et cartes de joueur

## Deux sujets distincts

1. **Cartons** : jaune, rouge, suspension.
2. **Cartes de joueur** : fiche visuelle (portrait, note, statistiques).

## Cartons

| Événement | Effet |
|---|---|
| Jaune | avertissement |
| Second jaune | rouge + suspension |
| Rouge direct | suspension + commission |
| Carton pour l'entraîneur | avertissement |

### Causes

- Faute (tacle, obstruction).
- Contestation.
- Anti-jeu.
- Perte de temps.
- Comportement violent.

### Suspensions

- 1 match après 2 jaunes (règle configurable).
- 1 à 3 matchs après rouge.
- Cumul sur une saison.
- Recours possible (option).

### Fair-play

- Points de fair-play par équipe.
- Qualification européenne (option).
- Amende (option).

## Cartes de joueur (UI)

| Élément | Contenu |
|---|---|
| Portrait | photo ou avatar |
| Nom | prénom + nom |
| Poste | principal + secondaire |
| Note | forme / moyenne |
| Attributs clés | 3 à 6 |
| Badge | club, nation |
| Rareté | option (jeu à collection) |

### Design

- Lisible en petit.
- Contraste élevé.
- Couleurs par club.
- Pas plus de 6 informations.
- Version compacte et version détaillée.

## Modèle de données

```
cards(id, match_id, player_id, type, minute, reason)
suspensions(id, player_id, competition_id, matches, start_date, end_date)
player_cards(id, player_id, season, appearances, goals, assists, rating, image_id)
```

## MVP

1. Jaune et rouge.
2. Suspension automatique.
3. Fiche joueur simple.
4. Puis cumul, recours, fair-play, rareté.

## Piège

Ne pas confondre **carton** (discipline) et **carte** (UI). Ce sont deux systèmes séparés.

## Approfondissement

### Règles de cartons

```text
si faute grave: rouge
si faute moyenne: jaune
si second jaune: rouge
```

### Suspensions

- 2 jaunes → 1 match.
- Rouge direct → 1 à 3 matchs.
- Cumul → suspension supplémentaire.

### Carte de joueur (spec UI)

| Zone | Contenu |
|---|---|
| Haut | portrait + note |
| Milieu | nom + poste |
| Bas | 3 attributs clés |

### Cas limites

- Carton annulé après recours.
- Joueur déjà suspendu.
- Carton en sélection.

### Critères de test

- Un joueur suspendu ne peut pas être aligné.
- La carte reste lisible en 200 px de large.
- Les cartons sont comptés par compétition.
