# 19 — Maillots

## Objectif

Gérer les tenues : types, couleurs, conflits, affichage 2D/3D, saisons.

## Types

| Type | Usage |
|---|---|
| Domicile | matchs à la maison |
| Extérieur | matchs à l'extérieur |
| Third | alternative |
| Gardien | tenue spécifique |
| Entraînement | hors match |
| Rétro | option esthétique |

## Conflits de couleurs

Règles à définir :

1. Les deux équipes ne peuvent pas avoir des maillots trop proches.
2. L'arbitre doit être distingué des deux équipes.
3. Le gardien doit être distingué des joueurs de champ et de l'arbitre.
4. Si conflit : l'équipe à domicile garde son maillot, l'extérieur change.

Algorithme simple : distance de couleur (RGB/HSV) + seuil + priorité domicile.

## 2D et 3D

| Version | Contenu |
|---|---|
| 2D | sprite du maillot (torse, manches, short, chaussettes) |
| 3D | textures appliquées au modèle du joueur |

Un maillot 3D n'est pas une image unique : c'est un ensemble de textures (torse, manches,
short, chaussettes, numéro, nom).

## Éléments graphiques

- Couleurs principales et secondaires.
- Motifs (rayures, pois, dégradé).
- Écusson du club.
- Logo de l'équipementier.
- Sponsor principal.
- Sponsor secondaire.
- Numéro et nom.
- Badge de compétition.

## Saisons

- Un maillot par saison.
- Conservation possible (option).
- Changement automatique à la nouvelle saison.
- Historique des tenues.

## Modèle de données

```
kits(id, club_id, season, type, primary_color, secondary_color, pattern, texture_path)
kit_assets(kit_id, part, file, license_id)
kit_assignments(match_id, club_id, kit_id)
```

## MVP

1. Trois tenues par club.
2. Détection simple des conflits.
3. Affichage 2D.
4. Puis 3D, sponsors, historique.

## Légalité

Les maillots réels sont protégés. Utiliser des créations originales ou des assets sous
licence. Voir [10](10-donnees-et-licences.md).

## Approfondissement

### Détection de conflit

```text
pour chaque paire d'équipes:
    si distance(couleur_a, couleur_b) < seuil:
        changer l'extérieur
    si distance(arbitre, équipe) < seuil:
        changer l'arbitre
```

### Règles de priorité

1. Domicile garde son maillot.
2. Extérieur change.
3. Gardien change si conflit.
4. Arbitre change en dernier.

### Rotation des saisons

- Nouveau kit à la nouvelle saison.
- Possibilité de conserver.
- Historique conservé.

### Critères de test

- Aucun conflit visuel.
- Le kit 3D correspond au kit 2D.
- Le numéro est lisible.
