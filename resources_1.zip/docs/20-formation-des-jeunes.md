# 20 — Formation des jeunes

## Objectif

Produire, développer et intégrer des jeunes joueurs.

## Le centre de formation

| Élément | Effet |
|---|---|
| Installations | qualité de l'intake et progression |
| Recrutement des jeunes | détection |
| Entraîneurs | progression |
| Responsable du centre (HOYD) | personnalité, style |
| Réputation | attirer de bons jeunes |

## Intake annuel

Une fois par an :

1. Génération d'une promotion (5 à 20 joueurs).
2. Niveau dépend des installations, du recrutement et de la réputation.
3. Potentiel (PA) variable, quelques pépites.
4. Personnalité et détermination.
5. Nationalité et poste.

Événement : `youth_intake`.

## Développement

| Facteur | Effet |
|---|---|
| Âge | progression forte avant 24 ans |
| Temps de jeu | accélère |
| Entraînement | oriente |
| Installations | plafond |
| Staff | qualité |
| Personnalité | régularité |
| Blessures | frein |
| Prêt | temps de jeu |

## CA / PA

- **CA** : niveau actuel.
- **PA** : potentiel maximal.
- Progression = f(âge, CA, PA, entraînement, temps de jeu, moral).

Formule simple pour un prototype :

```
progress = base * (PA - CA) / PA * age_factor * training_factor * playing_time
```

À équilibrer par simulation.

## Contrats et statut

- Premier contrat pro à 17–18 ans.
- Contrat jeune avant.
- Statut **homegrown** selon le temps passé au club.
- Protection contre le départ libre.

## Prêts

Un jeune a besoin de jouer : prêt dans un club plus faible, avec option de rappel.

## Départs

- Fin de contrat.
- Libération.
- Vente.
- Prêt.

## Modèle de données

```
academies(club_id, facilities, recruitment, reputation, hoyd_staff_id)
youth_intakes(id, club_id, season, player_id, quality)
player_development(player_id, date, ca_before, ca_after, reason)
homegrown_status(player_id, club_id, since, status)
```

## MVP

1. Intake annuel aléatoire pondéré.
2. CA/PA.
3. Progression mensuelle.
4. Premier contrat.
5. Puis prêts, mentoring, homegrown.

## Équilibrage

- Les pépites doivent être **rares**.
- Un jeune à fort PA ne doit pas être garanti titulaire.
- Le temps de jeu doit compter plus que l'entraînement seul.

## Approfondissement

### Génération de l'intake

```text
qualite = f(installations, recrutement, reputation, hasard)
nombre = 5 + qualite / 20
pour chaque jeune:
    PA = base + qualite * facteur_hasard
    CA = PA * (0.2 à 0.4)
    personnalite = tirage pondéré
```

### Progression

```text
progression = (PA - CA) * age_factor * training * playing_time * morale
CA = min(PA, CA + progression)
```

### Cas limites

- Trop de jeunes → effectif saturé.
- Jeune sans temps de jeu → stagnation.
- Blessure grave → progression réduite.

### Critères de test

- L'intake est annuel.
- Les pépites restent rares.
- Un jeune peut atteindre son PA avec du temps de jeu.
