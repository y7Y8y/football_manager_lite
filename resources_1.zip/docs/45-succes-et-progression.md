# 45 — Succès et progression

## Objectif

Donner des objectifs à long terme sans transformer le jeu en grinder.

## Types

| Type | Exemple |
|---|---|
| Succès | remporter la ligue |
| Défi | gagner avec un club de division 4 |
| Collection | recruter 10 joueurs formés au club |
| Palier | 100 matchs dirigés |
| Statistique | 500 buts marqués |

## Déclenchement

```text
événement → vérification des conditions → déblocage → notification
```

- Les succès sont **rétroactifs** si possible.
- Un succès ne doit jamais bloquer le jeu.
- Les conditions sont stockées en données, pas en code.

## Progression de profil

| Élément | Rôle |
|---|---|
| Niveau | expérience cumulée |
| Badges | catégories |
| Statistiques | matchs, titres, transferts |
| Collection | cartes ou trophées |

## Modèle de données

```
achievements(id, name, description, category, hidden, points)
achievement_conditions(achievement_id, type, target, params_json)
player_achievements(user_id, achievement_id, unlocked_at)
profile_stats(user_id, matches, wins, titles, goals, transfers)
```

## Bonnes pratiques

- Aucun succès lié à un achat.
- Aucun succès impossible à obtenir.
- Les succès cachés restent optionnels.
- Ne pas interrompre un match pour une notification.

## MVP

1. 20 succès simples.
2. Notification discrète.
3. Page de profil.
4. Puis défis, collection, statistiques.

## Critères de test

- Un succès se débloque une seule fois.
- Les conditions sont vérifiables.
- Aucun succès ne dépend d'un contenu payant.
