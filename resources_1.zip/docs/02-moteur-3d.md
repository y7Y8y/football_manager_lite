# 02 — Moteur 3D

## Pipeline de rendu

| Élément | Constat |
|---|---|
| Moteur | Unity 6 (`6000.0.52f1-fm26-05f1`) |
| Pipeline | **URP** — shaders `luxurp*`, `urplitmat` |
| Scripting | IL2CPP (`GameAssembly.dll`) |
| Shaders dédiés | cheveux `LuxURP Hair`, peau `LuxURP Skin`, tissu `clothsheen` |
| Post-traitement | bloom, bokeh, motion blur, upsampling |

Le rendu est **streamé** : 293 bundles Addressables (3 852 Mo) chargés à la demande.

## Familles de bundles

| Famille | Bundles | Taille | Contenu |
|---|---|---|---|
| `art-characters-*` | 33 | 1 495 Mo | Personnages modulaires |
| `art-lighting-skies` | 47 | 401 Mo | Ciels et éclairages |
| `scenes` | 11 | 365 Mo | Scènes Unity |
| `art-environments-*` | 11 | 363 Mo | Villes, bâtiments, végétation |
| `art-props-*` | 19 | 286 Mo | Objets, trophées, véhicules |
| `stadiums-*` | 4 | 390 Mo | Stades, sièges, panneaux, pelouse |
| `ui-*` | 75 | 174 Mo | Interface, polices, icônes, TIFO |
| `match-*` | 4 | 93 Mo | Scène, foule, cinématiques |
| `videos` | 3 | 63 Mo | Vidéos |
| `shaders` | 59 | 63 Mo | Shaders URP, compute shaders |
| `vfx`, `audio` | 2 | 37 Mo | Effets et son |

### Bundles les plus volumineux

| Bundle | Taille |
|---|---|
| `art-characters-male-outfits` | 378 Mo |
| `art-characters-female-outfits` | 355 Mo |
| `art-characters-male-hair` | 206 Mo |
| `stadiums-models` | 189 Mo |
| `art-environments-cityassets` | 185 Mo |
| `art-stadiums-pitch` | 138 Mo |
| `scenes_scenes_changingroomstateoftheart` | 115 Mo |
| `art-vegetation-trees` | 112 Mo |
| `art-characters-male-skin` | 108 Mo |
| `art-environments-ambientocclusionmaps` | 100 Mo |

## Personnages modulaires

- `art-characters-*-skin` : corps et peaux
- `-hair`, `-eyes`, `-facialhair`, `-accessories` : éléments de tête
- `-outfits` : vêtements civils
- `-kitresources` : application des maillots
- `-generic` : foule et staff
- `characterbuilder` : construction de personnage
- Compute shader `characterbuilder_scaledown` : réduction de textures
- `animskinnedhair`, `animskinnedarrayed` : cheveux animés

Le maillot est appliqué au modèle via les ressources de kit (doc 05).

## Animations (`shared\data\sianim`)

| Élément | Détail |
|---|---|
| Squelettes | `skeletons/{male,female}/*.json` |
| Expressions | `manager_facialexpressions_{m,f}.json` |
| Animations | `animations/*.cat`, `*.amd` |
| Locomotion | `locomotion_male` 34,7 Mo, `locomotion_female` 29,2 Mo |
| Pack | `pack.cat` 28 Mo |

Format propriétaire SI : les animations ne passent pas par l'Animator Unity standard.

## Rendu du match

| Bundle | Rôle |
|---|---|
| `match-scene` | Scène de match |
| `match-assets` (29 Mo) | Assets du match |
| `match-crowd` (11 Mo) | Foule |
| `match-cutscenes` (52 Mo) | Cinématiques |
| `stadiums-models` (189 Mo) | Géométrie des stades |
| `art-stadiums-pitch` (138 Mo) | Pelouse et marquages |
| `stadiums-seats`, `stadium-ads`, `tifo` | Sièges, panneaux, tribunes |
| `art-lighting-skies` (47) | Éclairage et ciels |
| `vfx` | Effets |

## Performance

- Chargement incrémental par Addressables.
- Scènes de vestiaire et de match séparées.
- `characterbuilder` réduit les textures des personnages secondaires.
- Cheveux et peau sont les assets les plus lourds.

## Zones non vérifiées

- Réglages URP exacts (ombres, MSAA, résolution).
- Physique du ballon : répartition entre `game_plugin.dll` et `GameAssembly.dll`.
- Utilisation éventuelle de DOTS/Burst.

## Approfondissement

### Budget par frame (60 fps)

| Poste | Budget |
|---|---|
| Simulation | 4 ms |
| Animation | 3 ms |
| Rendu CPU | 6 ms |
| Rendu GPU | 10 ms |
| UI | 2 ms |
| Marge | 8 ms |

### Seuils de LOD

| Distance | Modèle | Animation |
|---|---|---|
| 0–15 m | complet | 60 Hz |
| 15–40 m | moyen | 30 Hz |
| 40–80 m | simplifié | 15 Hz |
| > 80 m | impostor | figée |

### Mémoire

- Un personnage détaillé : 20–40 Mo (textures comprises).
- 22 joueurs + staff + foule : viser < 1,5 Go de VRAM.
- Streaming des textures par scène.
- Décharger les bundles de vestiaire avant le match.

### Cas limites

- 4K + ombres dynamiques + foule 3D = budget explosé.
- Chevaux/cheveux simulés = coût CPU imprévisible.
- Transparences superposées = surcharge GPU.

### Critères de test

- 60 fps stables en 1080p sur GPU milieu de gamme.
- Pas de chute sous 45 fps lors des cinématiques.
- Mémoire stable sur 90 minutes de match.
