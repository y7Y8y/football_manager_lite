# 33 — Arbitrage et VAR

## Objectif

Produire des décisions crédibles, contestables et explicables.

## Arbitre

| Attribut | Effet |
|---|---|
| Autorité | contestation |
| Vision | fautes vues |
| Sévérité | cartons |
| Avantage | jeu fluide |
| Homogénéité | cohérence |

## Décisions

- Faute / pas faute.
- Carton jaune / rouge.
- Penalty.
- Hors-jeu.
- Avantage.
- Temps additionnel.
- Sortie de but / corner / touche.

## Modèle de décision

```
perception → évaluation → décision → conséquence
```

- Chaque décision a une **probabilité** liée aux attributs.
- Une mauvaise décision doit rester **rare mais possible**.
- L'arbitre ne doit pas être un adversaire.

## VAR

| Situation | Révision |
|---|---|
| But | hors-jeu, faute |
| Penalty | contact, position |
| Rouge | gravité |
| Identité | mauvais joueur |

### Déroulement

1. Fait litigieux.
2. Vérification (durée).
3. Décision : validé, annulé, confirmé.
4. Communication.

### Options

- VAR activé / désactivé.
- Décisions automatiques ou manuelles.
- Niveau de controverse.
- Temps de vérification.

## Hors-jeu

- Ligne de hors-jeu.
- Moment de la passe.
- Position des défenseurs.
- Tolérance (option).

## Modèle de données

```
referees(id, name, authority, vision, severity, advantage, consistency)
referee_decisions(id, match_id, minute, type, decision, var_used, outcome)
var_reviews(id, match_id, minute, type, original_decision, final_decision)
```

## MVP

1. Fautes et cartons.
2. Penalty.
3. Hors-jeu simple.
4. Temps additionnel.
5. Puis VAR, avantage, contestation.

## Bonnes pratiques

- Toujours expliquer une décision (texte ou icône).
- Ne pas cacher les erreurs : elles font partie du jeu.
- Éviter les décisions aléatoires sans contexte.

## Approfondissement

### Probabilité de décision

```text
p_faute = f(severite, vision, contexte)
p_carton = f(severite, gravite)
p_penalty = f(position, contact, vision)
```

### Flux VAR

```text
fait → vérification → décision → communication
```

### Cas limites

- Décision déjà sifflée.
- Avantage en cours.
- Hors-jeu limite.

### Critères de test

- Aucune décision sans explication.
- Le VAR ne modifie pas plus de X décisions par match.
- Les stats de cartons restent cohérentes.
