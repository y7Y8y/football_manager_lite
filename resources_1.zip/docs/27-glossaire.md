# 27 — Glossaire

| Terme | Définition |
|---|---|
| **CA** | Current Ability : niveau actuel d'un joueur (0–200 dans FM) |
| **PA** | Potential Ability : niveau maximal atteignable |
| **xG** | Expected Goals : probabilité qu'un tir devienne but |
| **Bosman** | Transfert libre à la fin du contrat |
| **Homegrown** | Joueur formé au club ou dans le pays |
| **FFP** | Fair-play financier |
| **HOYD** | Head of Youth Development : responsable du centre de formation |
| **Intake** | Promotion annuelle de jeunes |
| **Newgen / regen** | Joueur généré par le jeu |
| **Squad status** | Statut promis dans l'effectif (titulaire, rotation, espoir) |
| **Release clause** | Clause libératoire |
| **Sell-on** | Pourcentage sur une revente future |
| **Buy-back** | Clause de rachat |
| **Option d'achat** | Droit (non obligatoire) d'acheter après un prêt |
| **Obligation d'achat** | Achat automatique après un prêt |
| **Wage budget** | Masse salariale disponible |
| **Transfer budget** | Budget transferts |
| **Familiarité tactique** | Niveau de maîtrise d'une tactique |
| **Dynamics** | Cohésion et ambiance du vestiaire |
| **Sharpness** | Rythme de match (fraîcheur compétitive) |
| **Fitness** | Condition physique générale |
| **LOD** | Level of Detail : modèle simplifié au loin |
| **URP** | Universal Render Pipeline (Unity) |
| **Addressables** | Système de chargement d'assets Unity |
| **Bundle** | Archive d'assets Unity |
| **Impostor** | Sprite utilisé pour représenter un objet 3D au loin |
| **Draw call** | Appel de rendu GPU |
| **Tick** | Pas de simulation |
| **Interpolation** | Lissage visuel entre deux ticks |
| **Event bus** | Diffusion d'événements entre systèmes |
| **MVP** | Minimum Viable Product : version minimale jouable |
| **Placeholder** | Asset temporaire de remplacement |
| **Sui generis** | Droit européen protégeant une base de données |

## Sigles de développement

| Sigle | Sens |
|---|---|
| CA/PA | Current/Potential Ability |
| UI | Interface utilisateur |
| UX | Expérience utilisateur |
| DB | Base de données |
| API | Interface de programmation |
| CI | Intégration continue |
| FPS | Images par seconde |

## Approfondissement

### Termes de conception

| Terme | Sens |
|---|---|
| Tick | pas de simulation |
| Snapshot | état figé pour le replay |
| Utility AI | IA qui note les options |
| Blend tree | mélange d'animations |
| LOD | niveau de détail |
| Impostor | sprite 3D au loin |
| Culling | suppression du non-visible |
| Batching | regroupement des draw calls |
| Data hub | écran de statistiques |
| Intake | promotion de jeunes |

### Termes de gestion

| Terme | Sens |
|---|---|
| CA / PA | niveau actuel / potentiel |
| Squad status | statut dans l'effectif |
| Release clause | clause libératoire |
| Sell-on | pourcentage de revente |
| Buy-back | clause de rachat |
| FFP | fair-play financier |
| Homegrown | formé au club/pays |

### Critères de test

- Chaque terme est utilisé de façon cohérente dans les docs.
- Aucun sigle n'est employé sans définition.
