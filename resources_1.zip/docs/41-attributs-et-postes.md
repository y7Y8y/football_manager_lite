# 41 — Attributs et postes

## Objectif

Décrire un joueur de façon lisible et exploitable par la simulation.

## Catégories

| Catégorie | Exemples |
|---|---|
| Technique | passe, tir, dribble, contrôle, tacle |
| Mental | vision, sang-froid, agressivité, placement |
| Physique | vitesse, accélération, endurance, force, détente |
| Gardien | réflexes, plongeon, jeu au pied, sortie |

## Échelle

- 1 à 20 (lisible, style FM).
- 1 à 100 (plus granulaire).
- Choisir **une** échelle et s'y tenir.

## Postes

| Poste | Rôle principal |
|---|---|
| GB | gardien |
| DC | défenseur central |
| DD / DG | latéraux |
| MDC | milieu défensif |
| MC | milieu central |
| MOC | meneur |
| AD / AG | ailiers |
| BU | buteur |

### Familiarité

Chaque joueur a un niveau par poste (0–100). Jouer hors poste réduit l'efficacité.

## Rôles et consignes

Un poste ne suffit pas : un DC peut être « stoppeur », « couverture » ou « relanceur ».
Voir [21](21-tactique-entrainement-moral.md).

## CA / PA

- **CA** : niveau actuel.
- **PA** : plafond.
- Le poids des attributs dépend du poste et du rôle.

```
ca = somme(attributs * poids_role) / normalisation
```

## Modèle de données

```
players(id, name, birthdate, nationality_id, primary_position, ca, pa)
player_attributes(player_id, attribute, value)
player_positions(player_id, position, familiarity)
roles(id, name, position, weights_json)
```

## MVP

1. 15 attributs.
2. 8 postes.
3. Familiarité par poste.
4. CA/PA.
5. Puis rôles, poids, formation.

## Piège

Trop d'attributs = illisible. Mieux vaut 15 attributs qui comptent que 50 qui dorment.

## Approfondissement

### Poids par rôle

| Rôle | Attributs clés |
|---|---|
| Buteur | tir, placement, sang-froid |
| Meneur | passe, vision, technique |
| Récupérateur | tacle, agressivité, endurance |
| Gardien | réflexes, plongeon, sortie |

### CA

```text
ca = somme(attribut * poids) / somme(poids)
```

### Familiarité

```text
efficacite = familiarite / 100
```

### Critères de test

- Un joueur hors poste est moins efficace.
- Le CA correspond aux attributs.
- Les rôles produisent des stats cohérentes.
