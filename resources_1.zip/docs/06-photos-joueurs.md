# 06 — Photos de joueurs

## Où sont les photos

Dans `LicensedData\{Core,Extra}` :

- `players-<pays>` : portraits sous licence
- `players-default` : portraits génériques
- `ui-newgen-portraits` (Addressables) : joueurs générés

| Catégorie | Bundles | Taille |
|---|---|---|
| `players-*` | 33 (dont `default`) | 415,8 Mo |

## Volumétrie (les plus gros)

| Bundle | Taille |
|---|---|
| `players-eng` | 84,4 Mo |
| `players-jpn` | 43,7 Mo |
| `players-ger` | 39,2 Mo |
| `players-ned` | 22,0 Mo |
| `players-fra` | 21,3 Mo |
| `players-kor` | 19,8 Mo |
| `players-usa` | 19,3 Mo |
| `players-bel` | 19,0 Mo |
| `players-sco` | 17,5 Mo |
| `players-wal` | 12,1 Mo |
| `players-swe_w` | 11,8 Mo |
| `players-pol` | 11,6 Mo |
| `players-uae` | 10,8 Mo |
| `players-ita` / `players-ita_w` | 4,9 / 5,3 Mo |

## Pays couverts

ARG, BEL, CAN, CRO, CZE, DEN (+F), ENG (+F), FRA, GER (+F), ITA (+F), JPN (+F), KOR, LAT,
LIT, MEX (+F), NED, NIR, POL, POR, SCO, SWE (F), UAE, USA (+F), WAL (+F).

Non couverts : Espagne, Brésil, Turquie, Russie, Ukraine, Grèce, etc.

## Format

- Images **dans les bundles** (pas de `.png` sur le disque).
- Chargement par UID joueur.
- Textures 2D pour l'UI.
- Les visages 3D des joueurs générés viennent du `characterbuilder` (doc 02), ce n'est pas
  la même chose.

## Surcharge utilisateur

```
Documents\Sports Interactive\Football Manager 26\graphics\faces\
├─ config.xml
└─ *.png
```

Mapping typique :

```xml
<record from="<uid>" to="graphics/pictures/person/<uid>/portrait"/>
```

- Packs « facepacks » communautaires.
- Images carrées, souvent 180×180 ou 300×300.
- Recharger le skin après installation.

## Bonnes pratiques

- Un dossier par pack, un `config.xml`.
- Nommer avec l'UID.
- Vérifier après mise à jour de la base.
- Éviter les images trop lourdes.

## Légalité

Photos protégées (droit à l'image, droit d'auteur). Ce dépôt ne contient aucune photo.

## Approfondissement

### Pipeline image

```text
source → recadrage visage → redimensionnement → compression WebP → cache
```

- Ratio 1:1.
- 180×180 pour les listes, 300×300 pour les fiches.
- Poids cible < 50 Ko par portrait.
- Nommage par UID joueur.

### Résolution

```text
si pack_utilisateur contient uid: retourner image
si bundle players-<pays> contient uid: retourner image
retourner players-default
```

### Cas limites

- Photo absente → avatar généré.
- Photo obsolète (transfert) → UID stable, pas de changement.
- Visage mal cadré → recadrage manuel.

### Critères de test

- 1 000 portraits chargés sans dépasser le budget mémoire.
- Aucun portrait déformé.
- Fallback visible et cohérent.
