# 16 — Avant-match

## Objectif

Préparer un match : information, tactique, effectif, consignes, motivation.

## Déroulement

```
1. Rapport de scout
2. Consignes sur l'adversaire
3. Préparation des phases arrêtées
4. Sélection de l'effectif
5. Tactique et consignes
6. Discours d'avant-match
7. Entrée sur le terrain
```

## Rapport de scout

| Information | Usage |
|---|---|
| Formation probable | adapter la tactique |
| Points forts / faibles | cibler |
| Joueurs clés | marquage |
| Coups de pied arrêtés | préparation |
| Pressing adverse | consignes |
| Météo / terrain | style de jeu |

La précision dépend de la qualité du scout et de sa connaissance du pays.

## Consignes sur l'adversaire

- Marquage individuel sur un joueur.
- Pressing sur un joueur ou une zone.
- Forcer un pied faible.
- Fermer un couloir.
- Consignes sur les phases arrêtées.

## Sélection de l'effectif

- 11 titulaires + 7 à 12 remplaçants selon la compétition.
- Forme, moral, condition physique, blessures, suspension.
- Statut d'effectif et temps de jeu promis.
- Rotation selon le calendrier.
- Capitaine.

## Tactique

Voir [21](21-tactique-entrainement-moral.md) : formation, rôles, consignes, familiarité.

## Discours d'avant-match

| Ton | Effet |
|---|---|
| Motivant | confiance, risque de pression |
| Calme | stabilité |
| Exigeant | responsabilisation |
| Rassurant | baisse du stress |
| Agressif | risque de fracture |

L'effet dépend du contexte (favori/outsider, série, rivalité) et de la personnalité des
joueurs.

## Météo et terrain

| Condition | Effet |
|---|---|
| Pluie | ballon rapide, contrôles difficiles |
| Neige | visibilité, vitesse réduite |
| Chaleur | endurance |
| Vent | centres et tirs |
| Terrain sec | rebonds |
| Terrain gras | jeu au sol |

## Modèle de données

```
match_prep(id, match_id, team_id, scout_report, opposition_instructions, set_piece_focus)
lineups(id, match_id, team_id, formation, player_id, position, role, duty, is_captain)
team_talks(id, match_id, team_id, tone, effect)
```

## MVP

1. Sélection des 11 + remplaçants.
2. Formation et rôles simples.
3. Rapport de scout basique.
4. Un discours avec 3 tons.
5. Puis consignes avancées et météo.

## Piège

Ne pas noyer le joueur sous les options : 3 à 5 décisions utiles valent mieux que 30 réglages
sans effet visible.

## Approfondissement

### Machine à états

```text
SCOUT → CONSIGNES → SELECTION → TACTIQUE → DISCOURS → MATCH
```

Chaque étape peut être sautée, mais l'ordre est conservé.

### Validation de l'effectif

- 11 titulaires.
- Au moins 1 gardien.
- Pas de joueur suspendu.
- Pas de joueur blessé.
- Limite de remplaçants respectée.

### Cas limites

- Moins de 11 joueurs disponibles → match perdu par forfait.
- Capitaine absent → nouveau capitaine.
- Météo extrême → consignes adaptées.

### Critères de test

- Impossible de lancer un match avec un effectif invalide.
- Les consignes sont bien transmises à la simulation.
