# 15 — Conférences de presse

## Objectif

Créer des décisions médiatiques qui influencent le moral, les supporters, le conseil et les
joueurs.

## Quand

| Contexte | Déclencheur |
|---|---|
| Avant-match | 24–48 h avant |
| Après-match | immédiatement après |
| Transfert | arrivée, départ, rumeur |
| Crise | série de défaites, conflit |
| Nomination | prise de poste |
| Fin de saison | bilan |

## Structure d'une conférence

1. 1 à 5 questions.
2. 2 à 4 réponses possibles par question.
3. Chaque réponse a des **effets** et un **ton**.

### Tons

| Ton | Effet typique |
|---|---|
| Assuré | confiance, pression sur l'adversaire |
| Humble | apaisement, soutien des joueurs |
| Agressif | tension, motivation ou fracture |
| Évasif | peu d'effet, crédibilité en baisse |
| Humoristique | détente, risque de mauvaise interprétation |

### Thèmes

Équipe, joueur individuel, tactique, arbitrage, rival, conseil, transfert, objectif,
supporteurs, journaliste.

## Effets

| Cible | Effet |
|---|---|
| Moral joueur | hausse/baisse |
| Relation joueur | confiance |
| Supporters | confiance |
| Conseil | patience |
| Médias | crédibilité |
| Adversaire | motivation (si provoqué) |
| Vestiaire | cohésion |

Les effets sont **bornés** et **cumulatifs avec rendements décroissants**.

## Journalistes

- Chaque journaliste a une relation (0–100).
- Les questions répétées lassent.
- Une réponse agressive peut créer un conflit durable.
- Un journaliste favorable peut poser des questions plus douces.

## Anti-répétition

- Pool de questions par contexte.
- Cooldown par question.
- Pondération par actualité (forme, blessure, transfert).
- Pas plus de X questions identiques par saison.

## Modèle de données

```
press_conferences(id, match_id, team_id, date, context)
press_questions(id, conference_id, theme, journalist_id, text)
press_answers(id, question_id, tone, text)
press_effects(id, answer_id, target_type, target_id, delta, duration)
journalists(id, name, outlet, relationship)
```

## MVP

1. 3 questions avant-match, 3 après-match.
2. 3 tons.
3. Effets sur moral et supporters.
4. Journal unique.
5. Puis journalistes, réputation, crises.

## Bonnes pratiques

- Toujours afficher l'effet **après** la réponse, pas avant.
- Ne pas rendre une réponse « toujours bonne ».
- Éviter les questions sans conséquence.
- Rendre les effets lisibles (icônes, couleurs).

## Approfondissement

### Sélection des questions

```text
candidats = questions(context, actualite)
pondérer par journalistes, forme, rivalité
tirer N questions sans répétition récente
```

### Plafonnement des effets

```text
effet = delta * (1 - confiance/100) * facteur_contexte
effet = clamp(effet, -10, +10)
```

### Cas limites

- Question répétée → ignorer.
- Réponse agressive en crise → effet amplifié.
- Journaliste hostile → questions plus dures.

### Critères de test

- Une conférence dure moins de 2 minutes.
- Aucune réponse n'est toujours optimale.
- Les effets sont visibles après coup.
