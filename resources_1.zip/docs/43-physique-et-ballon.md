# 43 — Physique et ballon

## Objectif

Un ballon crédible : passes, tirs, rebonds, effets, collisions.

## État du ballon

```
position (x, y, z)
velocity (vx, vy, vz)
spin (wx, wy, wz)
```

## Forces

| Force | Effet |
|---|---|
| Gravité | chute |
| Frottement | ralentissement |
| Magnus | effet (courbe) |
| Vent | déviation |
| Rebond | restitution |

## Équations simplifiées

```
v += (gravite + frottement + magnus + vent) * dt
p += v * dt
```

- `dt` fixe (ex. 1/60 s).
- Collisions avec sol, poteaux, joueurs.
- Restitution selon le matériau.

## Interactions joueur-ballon

| Action | Modèle |
|---|---|
| Passe | direction + puissance + effet |
| Tir | puissance + précision + effet |
| Dribble | contrôle + vitesse |
| Tacle | collision + perte de balle |
| Tête | direction + puissance |

## Précision

- Erreur dépendante de l'attribut.
- Erreur augmentée par la pression.
- Erreur réduite par la technique.

## Déterminisme

- Pas de physique dépendante du framerate.
- Tick fixe.
- Interpolation uniquement pour l'affichage.

## Modèle de données

```
ball_state(match_id, tick, x, y, z, vx, vy, vz, spin_x, spin_y, spin_z)
ball_events(id, match_id, tick, type, player_id, power, direction, outcome)
```

## MVP

1. Gravité + frottement.
2. Passe et tir.
3. Rebond au sol.
4. Poteaux.
5. Puis effet, vent, tête, tacles.

## Piège

Une physique trop réaliste coûte cher et casse le rythme. Viser **crédible et lisible**, pas
simulation exacte.

## Approfondissement

### Intégration

```text
v += a * dt
p += v * dt
```

- `dt` fixe.
- Subdiviser les collisions rapides.
- Clamp de vitesse.

### Rebond

```text
v_z = -v_z * restitution
v_x = v_x * friction
```

### Cas limites

- Ballon coincé.
- Collision avec plusieurs joueurs.
- Tir à très haute vitesse.

### Critères de test

- Pas de ballon qui traverse un mur.
- Rebonds cohérents.
- Même résultat avec la même graine.
