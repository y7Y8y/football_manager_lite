# 09 — Carte des systèmes du jeu

## Objectif

Ce document sert de **sommaire fonctionnel** : chaque système du jeu, son rôle, sa priorité
pour un MVP, et le document qui le détaille.

## Boucle principale

```
Pré-saison
  └─ effectif, staff, tactique, transferts, académie
       └─ Avant-match
            └─ Match (simulation + présentation 2D/3D)
                 └─ Après-match (presse, moral, finances, blessures)
                      └─ Mercato / entraînement / jeunesse
                           └─ saison suivante
```

## Systèmes couverts

| # | Système | Doc | Priorité MVP |
|---|---|---|---|
| 1 | Transferts et prêts | [11](11-transferts.md) | Haute |
| 2 | Présentation 2D/3D | [12](12-presentation-2d-3d.md) | Haute |
| 3 | Corners et coups de pied arrêtés | [13](13-coups-de-pied-arretes.md) | Haute |
| 4 | Événements de match | [14](14-evenements-de-match.md) | Haute |
| 5 | Conférences de presse | [15](15-conferences-de-presse.md) | Moyenne |
| 6 | Avant-match | [16](16-avant-match.md) | Haute |
| 7 | Compétitions et ligues | [17](17-competitions-et-ligues.md) | Haute |
| 8 | Rivalités, supporters, conseil | [18](18-rivalites-supporters-conseil.md) | Moyenne |
| 9 | Maillots | [19](19-maillots.md) | Moyenne |
| 10 | Formation des jeunes | [20](20-formation-des-jeunes.md) | Moyenne |
| 11 | Tactique, entraînement, moral | [21](21-tactique-entrainement-moral.md) | Haute |
| 12 | Finances et contrats | [22](22-finances-contrats.md) | Haute |
| 13 | Blessures et médical | [23](23-blessures-medical.md) | Moyenne |
| 14 | Recrutement et staff | [24](24-recrutement-staff.md) | Moyenne |
| 15 | Modèle de données | [25](25-modele-de-donnees.md) | Haute |
| 16 | Roadmap MVP | [26](26-roadmap-mvp.md) | Haute |
| 17 | Glossaire | [27](27-glossaire.md) | Basse |
| 18 | Animations | [28](28-animations.md) | Haute |
| 19 | Rendu et shaders | [29](29-rendu-et-shaders.md) | Haute |
| 20 | Cartons et cartes de joueur | [30](30-cartes-et-discipline.md) | Moyenne |
| 21 | Interface et UX | [31](31-interface-et-ux.md) | Haute |
| 22 | Audio et commentaires | [32](32-audio-et-commentaires.md) | Moyenne |
| 23 | Arbitrage et VAR | [33](33-arbitrage-et-var.md) | Moyenne |
| 24 | Météo et terrain | [34](34-meteo-et-terrain.md) | Basse |
| 25 | Stades et environnement | [35](35-stades-et-environnement.md) | Moyenne |
| 26 | Replays et temps forts | [36](36-replays-et-temps-forts.md) | Basse |
| 27 | Sauvegarde et persistance | [37](37-sauvegarde-et-persistance.md) | Haute |
| 28 | Localisation et accessibilité | [38](38-localisation-et-accessibilite.md) | Moyenne |
| 29 | Éditeur et modding | [39](39-editeur-et-modding.md) | Basse |
| 30 | Statistiques et analytics | [40](40-statistiques-et-analytics.md) | Moyenne |
| 31 | Attributs et postes | [41](41-attributs-et-postes.md) | Haute |
| 32 | IA de match | [42](42-ia-de-match.md) | Haute |
| 33 | Physique et ballon | [43](43-physique-et-ballon.md) | Haute |
| 34 | Multijoueur | [44](44-multijoueur.md) | Basse |
| 35 | Succès et progression | [45](45-succes-et-progression.md) | Basse |
| 36 | Tutoriel et onboarding | [46](46-tutoriel-et-onboarding.md) | Moyenne |
| 37 | Télémétrie et équilibrage | [47](47-telemetrie-et-equilibrage.md) | Basse |
| 38 | Ordre du tick | [48](48-ordre-du-tick.md) | Haute |
| 39 | Intégrité et anti-triche | [49](49-integrite-et-anticheat.md) | Basse |
| 40 | Monétisation et live ops | [50](50-monetisation-et-live-ops.md) | Basse |

## Ce qui est simulé vs présenté

| Couche | Contenu | Ne doit pas dépendre de |
|---|---|---|
| Simulation | décisions, physique, score, événements | modèles 3D, caméras |
| Présentation | 2D/3D, animations, caméras, sons | décisions de jeu |
| Interface | menus, fiches, tactiques | moteur de rendu du match |

Règle : un événement est produit par la simulation, puis **consommé** par la présentation.

## Parcours de lecture conseillé

1. [25 — modèle de données](25-modele-de-donnees.md) pour poser les tables.
2. [26 — roadmap MVP](26-roadmap-mvp.md) pour l'ordre de développement.
3. [11](11-transferts.md), [13](13-coups-de-pied-arretes.md),
   [14](14-evenements-de-match.md), [21](21-tactique-entrainement-moral.md) pour le cœur.
4. [41](41-attributs-et-postes.md), [42](42-ia-de-match.md), [43](43-physique-et-ballon.md)
   pour le moteur.
5. [12](12-presentation-2d-3d.md), [28](28-animations.md), [29](29-rendu-et-shaders.md)
   pour l'affichage.
6. Les autres docs au fur et à mesure.

## Règle d'or

Chaque système doit pouvoir tourner **sans interface** (mode texte / logs) avant d'être
branché sur le rendu. C'est ce qui permet de tester et d'équilibrer.

## Approfondissement

### Graphe de dépendances

```text
données → compétitions → calendrier → match
match → événements → stats → presse
match → blessures → effectif
transferts → effectif → tactique
académie → effectif
finances → transferts
```

### Ordre de tick recommandé

1. Temps et calendrier
2. IA des clubs
3. Contrats et transferts
4. Entraînement et blessures
5. Tactique et préparation
6. Match (si prévu)
7. Événements et stats
8. Presse et moral
9. Sauvegarde

### Critères de test

- Chaque système peut tourner en mode headless.
- Un système en panne ne bloque pas les autres.
- L'ordre est déterministe.
