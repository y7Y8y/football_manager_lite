# 01 — Architecture générale

## Résumé

Football Manager 26 est organisé en **deux couches distinctes** :

1. **Couche Unity 6** : interface, rendu 3D, audio, chargement d'assets (Addressables).
2. **Couche Sports Interactive native** : simulation du monde, moteur de match, règles.

Le rendu et la simulation sont **découplés** : Unity affiche l'état produit par le moteur SI.

## Fichiers racine observés

| Fichier | Taille | Rôle observé |
|---|---|---|
| `fm.exe` | 672 Ko | Bootstrap ; lance le runtime Unity |
| `UnityPlayer.dll` | 33,6 Mo | Runtime Unity |
| `GameAssembly.dll` | 53,6 Mo | Code C# compilé en natif (IL2CPP) |
| `fm_Data\Plugins\x86_64\game_plugin.dll` | 491 Mo | Cœur SI natif (v26.3.2, chaînes `MatchEngine`) |
| `baselib.dll` | 228 Ko | Bibliothèque de base SI |
| `fm_Data\` | — | Données runtime Unity |
| `shared\data\` | — | Données SI (base, compétitions, animations `.fmf`) |
| `special folders.xml` | 1,8 Ko | Racines de ressources et priorité |
| `fm_Data\StreamingAssets\` | — | `aa/` + `LicensedData/` |

## Séquence de démarrage (observée / déduite)

```
fm.exe
  └─ UnityPlayer.dll            runtime Unity 6
       └─ GameAssembly.dll      logique C# IL2CPP
            ├─ game_plugin.dll  simulation SI native
            ├─ aa/catalog.bin   catalogue Addressables
            └─ special folders.xml
                 ├─ app_data_folder      data/game_simulation
                 ├─ database_folder     shared/data/database
                 ├─ match_folder        shared/data/simatch
                 └─ ...                 (voir doc 07)
```

Les assets lourds sont chargés **à la demande** via Addressables.

## Les deux pipelines de contenu

### 1. Addressables Unity (`fm_Data\StreamingAssets\aa`)

- `catalog.bin`, `catalog.hash`, `settings.json`
- 293 bundles pour **3 852 Mo**
- Familles : `art-characters` (33), `art-lighting-skies` (47), `scenes` (11), `ui-*` (75),
  `shaders` (59), `match-*` (4), `stadiums-*` (4)
- UI, 3D des matchs, personnages, stades, effets

### 2. Données SI (`shared\data`)

- `database/db/2620` : base de données (doc 03)
- `sicomps/comps.dbc` : structure des compétitions
- `simatch.fmf`, `simatchshared.fmf` : ressources du moteur de match
- `sianim/` : squelettes et animations (doc 02)
- `editor.fmf` : ressources de l'éditeur
- `shared/tables.fmf` : tables de configuration

## Contenu licencié (`LicensedData`)

Second ensemble Addressables, séparé :

| Groupe | Bundles | Taille |
|---|---|---|
| `Core` | 188 | 600 Mo |
| `Extra` | 73 | 29 Mo |
| Total | 261 | 629 Mo |

Écussons, logos de compétitions, maillots 2D/3D, photos et drapeaux **des pays sous
licence** (docs 04 à 06).

## Points d'attention

- Les dossiers `db/2300` à `db/2430` sont des bases d'anciennes versions (FM23/FM24) ; FM26
  utilise `2620`.
- Le moteur de match est natif : `simatch*.fmf` contient des ressources, pas du code.
- Le contenu licencié est identifiable par pays dans les noms de bundles
  (`club-eng`, `kits3d-fra`, `players-jpn`).

## Zones non vérifiées

- Format interne des `.dat` au-delà du conteneur et de LZ4.
- Rôle précis de `reflex.dll`, `version.dll`, `steamclient64.dll`.
- Répartition exacte entre code natif SI et code C#.

## Approfondissement

### Modules et responsabilités

| Module | Responsabilité | Dépend de |
|---|---|---|
| `fm.exe` | bootstrap, arguments, mise à jour | UnityPlayer |
| `UnityPlayer.dll` | boucle Unity, scènes | GameAssembly |
| `GameAssembly.dll` | logique C# IL2CPP, UI, chargement | game_plugin |
| `game_plugin.dll` | simulation, match engine, règles | données SI |
| `aa/` | assets Unity streamés | catalogue |
| `LicensedData/` | assets sous licence | catalogue secondaire |
| `shared/data/` | base, compétitions, animations | Resource Manager |

### Séquence détaillée

```text
1. fm.exe lit les arguments et le fichier de configuration
2. UnityPlayer initialise le runtime et la scène de démarrage
3. GameAssembly charge les assemblies et les plugins natifs
4. game_plugin initialise le monde, la base et les règles
5. Le catalogue Addressables est ouvert
6. special folders.xml enregistre les racines de ressources
7. L'UI principale est chargée
8. Les assets sont demandés à la demande (streaming)
```

### Modes de défaillance

- Base absente ou version incompatible → écran d'erreur au démarrage.
- Bundle corrompu → asset manquant ou crash de scène.
- Plugin natif incompatible → échec avant l'UI.
- Sauvegarde d'une version supérieure → refus de chargement.

### Critères de test

- Démarrage à froid < 30 s sur SSD.
- Aucun accès disque bloquant sur le thread principal.
- Les assets lourds ne sont pas chargés avant la scène qui les utilise.
