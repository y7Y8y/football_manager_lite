# 17 — Compétitions et ligues

## Objectif

Gérer les championnats, coupes, compétitions continentales, calendriers et règles.

## Types

| Type | Exemple | Format |
|---|---|---|
| Championnat | Ligue 1 | aller-retour, points |
| Coupe nationale | Coupe de France | élimination directe |
| Coupe de la ligue | Carabao Cup | élimination directe |
| Supercoupe | Trophée des champions | match unique |
| Continental | Ligue des champions | groupes + élimination |
| International | Coupe du monde | groupes + élimination |

## Structure d'une ligue

- Nombre d'équipes (10 à 24).
- Matchs aller/retour ou aller simple.
- Promotion / relégation.
- Barrages.
- Places continentales.
- Règles de départage : points, différence de buts, buts marqués, confrontations directes.

## Calendrier

- Génération des journées (round-robin).
- Éviter les conflits : coupes, Europe, sélections.
- Trêves internationales.
- Pause hivernale selon le pays.
- Reports (météo, coupes).

## Règles à stocker

- Limite de joueurs enregistrés.
- Quota d'étrangers.
- Règle homegrown.
- Limite de prêts.
- Salaire minimum.
- Fair-play financier.
- Nombre de remplaçants.
- Cartons et suspensions.

## Petites ligues

| Caractéristique | Effet |
|---|---|
| Faible réputation | recrutement difficile |
| Budget limité | ventes obligatoires |
| Peu de médias | moins de pression |
| Peu de scouts | connaissance limitée |
| Droits TV faibles | finances fragiles |
| Calendrier court | moins de rotation |

Une petite ligue est un bon **mode de départ** pour un jeu : moins de données, boucle plus
rapide.

## Finances de compétition

- Droits TV.
- Recettes de billetterie.
- Primes de classement.
- Primes de coupe.
- Répartition continentale.

## Modèle de données

```
countries(id, name, reputation)
competitions(id, country_id, name, type, reputation, level)
competition_rules(id, competition_id, max_squad, foreign_limit, homegrown_min,
                  loan_limit, ffp_enabled)
seasons(id, competition_id, year, start_date, end_date)
fixtures(id, season_id, round, home_club_id, away_club_id, date, status)
standings(season_id, club_id, played, won, drawn, lost, goals_for, goals_against, points)
```

## MVP

1. Une ligue, 10 à 20 clubs, aller-retour.
2. Classement et départage.
3. Une coupe nationale simple.
4. Calendrier sans conflit.
5. Puis Europe, barrages, règles avancées.

## Piège

Ne pas coder les règles dans le moteur de match : elles appartiennent à la compétition.

## Approfondissement

### Génération du calendrier (round-robin)

```text
équipes = liste
si nombre impair: ajouter un bye
pour chaque journée:
    apparier i avec n-1-i
    alterner domicile/extérieur
    faire tourner les équipes
```

### Départage

1. Points
2. Différence de buts
3. Buts marqués
4. Confrontations directes
5. Fair-play
6. Tirage au sort

### Cas limites

- Club dissous en cours de saison.
- Match reporté.
- Calendrier surchargé.
- Barrages.

### Critères de test

- Chaque équipe joue le même nombre de matchs.
- Aucune équipe ne joue deux fois le même jour.
- Le classement se recalcule correctement.
