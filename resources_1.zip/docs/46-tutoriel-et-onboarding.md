# 46 — Tutoriel et onboarding

## Objectif

Faire comprendre le jeu en moins de 15 minutes, sans noyer le joueur.

## Première session

```text
Écran titre → Choix du club → Visite guidée → Premier match → Premier transfert
```

## Étapes guidées

| Étape | Action |
|---|---|
| 1 | Choisir un club |
| 2 | Lire l'effectif |
| 3 | Choisir une tactique |
| 4 | Sélectionner les 11 |
| 5 | Jouer un match |
| 6 | Faire un transfert |
| 7 | Sauvegarder |

Chaque étape : une action, une explication, un bouton « passer ».

## Règles

- Ne jamais bloquer le joueur.
- Expliquer **pourquoi**, pas seulement **où cliquer**.
- Utiliser des infobulles contextuelles.
- Proposer un mode expert (tutoriel désactivé).

## Difficulté

| Niveau | Aides |
|---|---|
| Débutant | tout expliqué, conseils |
| Normal | infobulles |
| Expert | aucune aide |

## Modèle de données

```
tutorial_steps(id, order, screen, action, text_key, optional)
tutorial_progress(user_id, step_id, completed_at)
```

## MVP

1. 7 étapes.
2. Infobulles.
3. Bouton passer.
4. Puis mode expert, conseils dynamiques.

## Critères de test

- Un débutant termine le tutoriel.
- Le tutoriel ne bloque jamais.
- Les étapes sont traduisibles.
