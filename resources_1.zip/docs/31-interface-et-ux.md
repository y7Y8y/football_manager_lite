# 31 — Interface et UX

## Objectif

Permettre de jouer sans manuel : information claire, navigation rapide, décisions
compréhensibles.

## Écrans principaux

| Écran | Rôle |
|---|---|
| Accueil / inbox | actualités, messages, échéances |
| Effectif | joueurs, statuts, contrats |
| Tactique | formation, rôles, consignes |
| Calendrier | matchs, résultats |
| Classement | positions, forme |
| Transferts | recherches, offres, budget |
| Finances | revenus, dépenses, budgets |
| Centre de formation | jeunes, intake |
| Staff | recrutement, attributions |
| Match | avant, pendant, après |
| Fiche joueur | attributs, stats, contrat |

## Navigation

- Barre latérale persistante.
- Fil d'Ariane.
- Recherche globale.
- Raccourcis clavier.
- Retour arrière cohérent.
- Maximum 3 clics pour une action courante.

## Composants

- Tableaux triables et filtrables.
- Tooltips sur les attributs.
- Badges (forme, blessure, suspension).
- Barres de progression.
- Notifications non bloquantes.
- Confirmations pour les actions irréversibles.

## Hiérarchie visuelle

1. Résultat / score.
2. Action principale.
3. Contexte.
4. Détails.

Une seule action principale par écran.

## Lisibilité

- Contraste suffisant.
- Taille de police réglable.
- Icônes + texte.
- Pas de couleur seule pour une information.
- Mode daltonien.
- Densité d'information réglable.

## Accessibilité

- Navigation clavier complète.
- Focus visible.
- Sous-titres.
- Remapping des touches.
- Réduction des animations.
- Textes alternatifs.

## Performance perçue

- Affichage immédiat, chargement en arrière-plan.
- Squelettes de chargement.
- Pas de blocage sur les longues listes.
- Pagination ou virtualisation.

## Modèle de données

```
ui_settings(user_id, language, theme, font_scale, colorblind_mode, reduced_motion)
shortcuts(user_id, action, key)
```

## MVP

1. 6 écrans : effectif, tactique, calendrier, classement, transferts, fiche joueur.
2. Navigation latérale.
3. Tableaux triables.
4. Tooltips.
5. Puis accessibilité et personnalisation.

## Piège

Trop d'informations tue l'information. Mieux vaut 5 indicateurs utiles que 30 chiffres.

## Approfondissement

### Carte de navigation

```text
Accueil → Effectif → Fiche joueur
Accueil → Tactique → Match
Accueil → Transferts → Offre
Accueil → Finances
```

### Composants clés

- Tableau virtualisé.
- Filtre multi-critères.
- Panneau de détail.
- Confirmation destructive.
- Notification.

### Règles UX

- Une action principale par écran.
- Maximum 3 clics.
- Toujours un retour.
- Jamais de perte de saisie.

### Critères de test

- Navigation clavier complète.
- Aucun écran bloquant.
- Temps d'affichage < 200 ms.
