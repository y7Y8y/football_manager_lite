# 18 — Rivalités, supporters et conseil

## Objectif

Donner du contexte émotionnel et des conséquences aux résultats.

## Rivalités

| Type | Exemple | Intensité |
|---|---|---|
| Derby local | deux clubs de la même ville | très forte |
| Régional | même région | forte |
| Historique | ancienne finale, conflit | variable |
| Sportif | lutte pour le titre | moyenne |
| Financier | même propriétaire, transfert | faible |

### Effets

- Motivation des joueurs et des supporters.
- Affluence.
- Pression sur l'entraîneur.
- Ton des médias.
- Prix des billets (option).

### Modèle

```
rivalries(club_a_id, club_b_id, intensity, origin)
```

## Supporters

| Indicateur | Effet |
|---|---|
| Confiance | soutien, ambiance |
| Attente | tolérance aux résultats |
| Affluence | recettes |
| Mécontentement | banderoles, protestations |
| Patience | délai avant crise |

La confiance monte avec les victoires, le style de jeu, les recrues et les déclarations.
Elle baisse avec les défaites, les ventes de joueurs aimés et les conflits.

## Conseil d'administration

| Élément | Rôle |
|---|---|
| Objectif de saison | minimum attendu |
| Budget | transferts et salaires |
| Patience | tolérance aux mauvais résultats |
| Confiance | risque de licenciement |
| Projet | jeune, ambitieux, économique |

### Objectifs typiques

- Remporter le championnat.
- Terminer dans les 4 premiers.
- Se maintenir.
- Atteindre un tour de coupe.
- Développer des jeunes.
- Réduire la masse salariale.

### Licenciement

Déclenché par : confiance basse + série de défaites + objectif non atteint + pression des
supporters. Un délai de grâce évite les décisions trop brutales.

## Médias

- Couverture locale/nationale.
- Rumeurs de départ.
- Déclarations qui influencent la confiance.
- Voir [15](15-conferences-de-presse.md).

## Modèle de données

```
fan_confidence(club_id, value, last_update)
board_expectations(club_id, season_id, objective, min_position, patience, confidence)
board_decisions(club_id, date, type, reason)
```

## MVP

1. Une rivalité par club.
2. Confiance des supporters (0–100).
3. Objectif de saison.
4. Confiance du conseil.
5. Licenciement si seuil bas.
6. Puis protestations, médias, projets.

## Bonnes pratiques

- Rendre les seuils **lisibles** dans l'interface.
- Éviter les licenciements aléatoires.
- Toujours expliquer une décision du conseil.

## Approfondissement

### Intensité de rivalité

```text
intensite = base + historique + proximite + enjeu
intensite = clamp(intensite, 0, 100)
```

### Effets

| Intensité | Effet |
|---|---|
| 0–30 | neutre |
| 31–60 | ambiance, motivation |
| 61–85 | pression, affluence |
| 86–100 | crise possible |

### Confiance du conseil

```text
confiance += victoires * 2 - defaites * 3
confiance += objectif_atteint * 10
confiance = clamp(confiance, 0, 100)
```

### Critères de test

- Un licenciement n'arrive pas après un seul match.
- La confiance évolue de façon lisible.
- Les effets de rivalité sont visibles.
