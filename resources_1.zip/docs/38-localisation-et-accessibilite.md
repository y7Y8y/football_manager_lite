# 38 — Localisation et accessibilité

## Localisation

### Principes

- Aucun texte en dur dans le code.
- Clés centralisées.
- Fichiers par langue.
- Contexte pour les traducteurs.
- Gestion des pluriels.
- Formats de date, heure, monnaie.

```
locales/
├─ fr.json
├─ en.json
└─ es.json
```

### Exemple

```json
{
  "match.goal": "{player} marque à la {minute}e minute !",
  "transfer.offer": "Offre de {amount} pour {player}"
}
```

### Pièges

- Concaténation de phrases.
- Genre grammatical.
- Pluriels irréguliers.
- Textes trop longs dans les boutons.
- RTL (arabe, hébreu).

## Accessibilité

| Besoin | Solution |
|---|---|
| Malvoyance | contraste, taille de police, zoom |
| Daltonisme | palettes alternatives, formes |
| Motricité | clavier, remapping, pas de QTE |
| Audition | sous-titres, indicateurs visuels |
| Cognition | textes simples, résumés |
| Photosensibilité | réduction des flashs |

### Options

- Taille de police (3 niveaux).
- Contraste élevé.
- Mode daltonien.
- Réduction des animations.
- Sous-titres.
- Remapping complet.
- Aide contextuelle.

## Modèle de données

```
locales(id, code, name, direction)
translations(locale_id, key, value)
accessibility_settings(user_id, font_scale, contrast, colorblind, reduced_motion)
```

## MVP

1. Français + anglais.
2. Clés externalisées.
3. Taille de police.
4. Contraste.
5. Puis autres langues, RTL, sous-titres.

## Piège

Traduire à la fin coûte plus cher que prévoir les clés dès le début.

## Approfondissement

### Nommage des clés

```text
domaine.ecran.element
match.goal
transfer.offer
menu.settings
```

### Pluriels

```text
{count, plural, one {# match} other {# matchs}}
```

### Accessibilité

- Contraste 4.5:1.
- Police 3 tailles.
- Mode daltonien.
- Sous-titres.
- Remapping.

### Critères de test

- Aucun texte en dur.
- Aucun débordement en allemand.
- Navigation clavier complète.
