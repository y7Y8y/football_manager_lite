# 49 — Intégrité et anti-triche

## Objectif

Protéger les sauvegardes, les classements et le multijoueur sans punir les joueurs honnêtes.

## Menaces

| Menace | Exemple |
|---|---|
| Édition de sauvegarde | modifier un budget |
| Rejeu | rejouer un match jusqu'à gagner |
| Vitesse | accélérer le temps |
| Multijoueur | envoyer une action invalide |
| Mods | injecter du code |

## Sauvegardes

- Checksum par fichier.
- Signature optionnelle.
- Détection de modification.
- Mode « sauvegarde verrouillée » pour les classements.

## Rejeu

- Graine enregistrée.
- Journal des actions.
- Vérification côté serveur.
- Refus si incohérence.

## Multijoueur

- Serveur autoritaire.
- Validation de chaque action.
- Limitation de débit.
- Journal d'audit.

## Mods

- Sandbox.
- Pas d'accès réseau.
- Validation des assets.
- Signature optionnelle.

## Modèle de données

```
save_integrity(save_id, checksum, signature, created_at)
action_log(id, match_id, user_id, tick, action, payload, hash)
integrity_events(id, user_id, type, severity, created_at)
```

## Bonnes pratiques

- Ne pas bloquer un joueur solo qui modifie sa sauvegarde.
- Réserver la vérification stricte au multijoueur et aux classements.
- Expliquer clairement un refus.
- Prévoir une procédure d'appel.

## MVP

1. Checksum de sauvegarde.
2. Journal d'actions.
3. Validation serveur minimale.
4. Puis signature, classements, appels.

## Critères de test

- Une sauvegarde modifiée est détectée.
- Un rejeu incohérent est refusé.
- Un joueur solo n'est pas bloqué.
