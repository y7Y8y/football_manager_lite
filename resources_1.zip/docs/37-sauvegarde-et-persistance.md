# 37 — Sauvegarde et persistance

## Objectif

Ne jamais perdre une partie, même après une mise à jour.

## Ce qu'il faut sauvegarder

- Monde : clubs, joueurs, contrats, finances.
- Compétitions : saisons, calendrier, classements.
- État du match en cours (option).
- Historique des événements.
- Tactiques et entraînement.
- Paramètres utilisateur.
- **Graine aléatoire** (RNG seed) pour la reproductibilité.

## Formats

| Format | Avantage | Inconvénient |
|---|---|---|
| JSON | lisible, debug | lourd |
| SQLite | requêtes, intégrité | dépendance |
| Binaire | rapide, compact | migration difficile |

Recommandation : **SQLite** pour le monde + JSON pour les paramètres.

## Versioning

- Champ `schema_version`.
- Migrations séquentielles.
- Sauvegarde automatique avant migration.
- Refus clair si version trop ancienne.

```
save_v1 → migrate_v2 → migrate_v3
```

## Sauvegarde automatique

- Après chaque match.
- Avant un transfert important.
- À la fermeture.
- Rotation (3 à 5 slots).
- Sauvegarde manuelle séparée.

## Intégrité

- Écriture atomique (fichier temporaire + renommage).
- Checksum.
- Détection de corruption.
- Restauration du slot précédent.

## Cloud (option)

- Synchronisation.
- Conflits : garder la version la plus récente + copie.
- Chiffrement.

## Modèle de données

```
saves(id, name, created_at, schema_version, seed, checksum)
save_slots(id, save_id, slot, path, updated_at)
```

## MVP

1. Sauvegarde manuelle.
2. Chargement.
3. Autosave après match.
4. Version de schéma.
5. Puis migration, cloud, checksum.

## Piège

Une sauvegarde non versionnée devient impossible à maintenir dès la première mise à jour.

## Approfondissement

### Écriture atomique

```text
écrire dans save.tmp
flush
renommer save.tmp → save.db
```

### Migration

```text
si version < actuelle:
    sauvegarder
    appliquer migrations
    vérifier
```

### Cas limites

- Coupure pendant l'écriture.
- Disque plein.
- Sauvegarde d'une version future.

### Critères de test

- Aucune sauvegarde corrompue après coupure.
- Migration testée.
- Autosave ne bloque pas le jeu.
