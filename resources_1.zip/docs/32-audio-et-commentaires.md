# 32 — Audio et commentaires

## Objectif

Donner de l'ambiance et de la compréhension sans fatiguer le joueur.

## Trois couches

1. **Ambiance** : foule, stade, météo.
2. **Effets** : ballon, sifflet, poteau, filet.
3. **Commentaires** : voix ou texte.

## Effets

| Son | Déclencheur |
|---|---|
| Coup de sifflet | début, fin, faute |
| Frappe | tir |
| Poteau | collision poteau |
| Filet | but |
| Tacle | contact |
| Cris | occasion, but |
| Huées | mauvaise décision |
| Encouragements | momentum |

## Ambiance

- Boucle de foule par intensité (calme, tension, joie).
- Réactions synchronisées avec les événements.
- Variation par tribune.
- Volume adaptatif.

## Commentaires

### Génération

```
événement → sélection de template → variables → phrase
```

- Templates par type.
- Variables : joueur, équipe, minute, score.
- Variantes pour éviter la répétition.
- Priorité : but > carton > occasion > passe.
- Cooldown par template.
- Ton selon le contexte (derby, crise, finale).

### Texte vs voix

| Mode | Avantage |
|---|---|
| Texte | pas de doublage, facile à traduire |
| Voix | immersion, coût élevé |

Un jeu indie peut commencer par du **commentaire texte** + ambiance sonore.

## Mixage

- Ducking : baisser la foule quand le commentaire parle.
- Bus : ambiance, effets, voix, musique.
- Volume par bus.
- Mode nuit / casque.

## Modèle de données

```
audio_events(id, type, asset, volume, pitch_variation)
commentary_lines(id, event_type, template, language, priority)
commentary_cooldowns(template_id, last_used)
```

## MVP

1. Sifflet, frappe, but, foule.
2. Commentaire texte.
3. Ducking.
4. Puis voix, variantes, langues.

## Piège

Trop de commentaires = bruit. Le silence est aussi un outil.

## Approfondissement

### Bus de mixage

```text
Master
├─ Ambiance
├─ Effets
├─ Voix
└─ Musique
```

### Priorité des commentaires

1. But
2. Carton rouge
3. Penalty
4. Occasion
5. Passe

### Anti-répétition

```text
si template utilisé récemment: choisir un autre
cooldown = 3 commentaires
```

### Critères de test

- Le commentaire ne coupe pas l'ambiance.
- Aucun doublon sur 5 minutes.
- Volume réglable par bus.
