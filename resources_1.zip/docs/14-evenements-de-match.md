# 14 — Événements de match

## Objectif

Définir un langage d'événements unique, produit par la simulation et consommé par l'UI,
la 2D, la 3D et les commentaires.

## Principe

Un événement est un **objet immuable** avec un type, un temps, des acteurs et un contexte.
Tout le reste (affichage, stats, presse) en dérive.

## Taxonomie

| Catégorie | Types |
|---|---|
| Match | `kickoff`, `half_time`, `full_time`, `extra_time_start`, `shootout_start` |
| Score | `goal`, `own_goal`, `assist`, `penalty_goal`, `goal_disallowed` |
| Discipline | `yellow_card`, `second_yellow`, `red_card`, `foul`, `dive` |
| Jeu | `pass`, `shot`, `shot_on_target`, `save`, `tackle`, `interception`, `clearance` |
| Arrêts de jeu | `corner`, `free_kick`, `penalty`, `throw_in`, `goal_kick`, `offside` |
| Effectif | `substitution`, `injury`, `return_from_injury` |
| Temps | `added_time`, `stoppage` |
| Divers | `var_check`, `weather_change`, `pitch_invasion` |

## Structure d'un événement

```
Event:
  id
  match_id
  minute
  second
  type
  team_id
  player_id (optionnel)
  secondary_player_id (passeur, fautif)
  position (x, y)
  outcome (success, fail, goal, saved)
  metadata (json)
```

## Flux

```
Simulation → EventBus → { UI, 2D, 3D, commentaires, statistiques, presse }
```

- La simulation publie.
- Les consommateurs s'abonnent.
- Aucun consommateur ne modifie l'événement.

## Statistiques dérivées

Possession, tirs, tirs cadrés, xG, passes, précision, corners, fautes, cartons, distance,
sprints, duels gagnés.

Les stats se calculent **à partir des événements**, pas en parallèle.

## Commentaires

- Un modèle de phrase par type + variantes.
- Variables : joueur, équipe, minute, score.
- Éviter la répétition (pool + cooldown).
- Priorité : but > carton > occasion > passe.

## Timeline

- Fil chronologique filtrable.
- Moments clés = événements de priorité haute.
- Replay = rejouer une fenêtre d'événements.

## Modèle de données

```
match_events(id, match_id, minute, second, type, team_id, player_id,
             secondary_player_id, x, y, outcome, metadata)
match_stats(match_id, team_id, possession, shots, shots_on_target, xg,
            passes, pass_accuracy, corners, fouls, yellows, reds)
```

## MVP

1. But, carton, remplacement, mi-temps, fin.
2. Timeline + score.
3. Statistiques de base.
4. Commentaires simples.
5. Puis xG, heatmaps, replays.

## Piège à éviter

Ne pas coder la logique d'affichage dans la simulation. Un événement doit rester **pur
data**.

## Approfondissement

### Ordre et idempotence

- Les événements sont ordonnés par `(minute, second, sequence)`.
- Un événement ne doit jamais être appliqué deux fois.
- Les consommateurs sont en lecture seule.
- Les stats se recalculent depuis zéro si nécessaire.

### Schéma minimal

```text
Event = {
  id, match_id, minute, second, sequence,
  type, team_id, player_id, secondary_player_id,
  x, y, outcome, metadata
}
```

### Cas limites

- But refusé après VAR → événement `goal_disallowed`.
- Carton annulé → événement de correction.
- Match abandonné → statut spécial.

### Critères de test

- Rejouer le même flux donne les mêmes stats.
- Aucun événement orphelin.
- La timeline est triée.
