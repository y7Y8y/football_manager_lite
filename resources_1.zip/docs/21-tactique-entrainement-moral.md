# 21 — Tactique, entraînement et moral

## Tactique

### Formation

Exemples : 4-4-2, 4-3-3, 4-2-3-1, 3-5-2, 5-3-2.

Une formation définit :
- les **positions de base** ;
- les **zones** couvertes ;
- les **transitions** (offensive/défensive).

### Rôles

| Rôle | Exemple |
|---|---|
| Gardien | gardien classique, libéro |
| Défenseur | central, latéral, ailier défensif |
| Milieu | récupérateur, meneur, box-to-box |
| Attaquant | buteur, faux neuf, ailier |

### Consignes

- Bloc haut / bas.
- Pressing : fort, moyen, bas.
- Largeur.
- Rythme.
- Passes : courtes, directes, mixtes.
- Tirs : fréquents, raisonnés.
- Hors-jeu.
- Marquage.

### Familiarité

Chaque tactique a un niveau de familiarité (0–100) qui monte à l'entraînement et en match.
Une tactique inconnue produit des erreurs de positionnement.

## Entraînement

| Type | Effet |
|---|---|
| Général | équilibre |
| Attaque | finition, passes |
| Défense | placement, tacles |
| Physique | endurance, force |
| Technique | contrôle, dribble |
| Tactique | familiarité |
| Repos | récupération |

- Intensité : faible, normale, élevée (risque de blessure).
- Programme individuel par joueur.
- Préparation des phases arrêtées (voir [13](13-coups-de-pied-arretes.md)).

## Moral et dynamique

| Indicateur | Effet |
|---|---|
| Moral individuel | performance |
| Cohésion | passes, entraide |
| Pression | erreurs |
| Confiance | prise de risque |
| Relations | conflits |

Sources de variation : résultats, temps de jeu, discours, presse, transferts, salaire,
blessures, rivalité.

## Modèle de données

```
tactics(id, club_id, name, formation, mentality, pressing, tempo, width)
tactic_slots(tactic_id, position, role, duty, player_id)
tactic_familiarity(club_id, tactic_id, value)
training_programs(id, club_id, focus, intensity)
player_training(player_id, program_id, focus, intensity)
morale(player_id, value, last_event)
dynamics(club_id, cohesion, pressure, confidence)
```

## MVP

1. Une formation + rôles simples.
2. Familiarité qui monte.
3. Entraînement général avec intensité.
4. Moral individuel.
5. Puis consignes fines, dynamique de groupe, entraînement individuel.

## Bonnes pratiques

- Chaque consigne doit avoir un **effet mesurable**.
- Afficher les conséquences (risque de blessure, fatigue).
- Éviter les tactiques « gagnantes » uniques.

## Approfondissement

### Familiarité

```text
familiarite += entrainement_tactique * 0.5
familiarite += match_avec_tactique * 0.2
familiarite -= changement_massif * 5
familiarite = clamp(familiarite, 0, 100)
```

### Effet de l'intensité

| Intensité | Progression | Risque blessure |
|---|---|---|
| Faible | 0.5× | 0.5× |
| Normale | 1× | 1× |
| Élevée | 1.4× | 2× |

### Moral

```text
moral += resultat * 3
moral += temps_de_jeu * 1
moral += discours
moral = clamp(moral, 0, 100)
```

### Critères de test

- Une tactique inconnue produit des erreurs.
- L'intensité élevée augmente les blessures.
- Le moral influence la performance de façon mesurable.
