# 13 — Corners et coups de pied arrêtés

## Objectif

Modéliser les phases arrêtées : corners, coups francs, penalties, touches, six mètres.

## Corners

### Paramètres d'un corner

| Paramètre | Valeurs |
|---|---|
| Côté | gauche / droit |
| Pied du tireur | droit / gauche |
| Type de centre | rentrant, sortant, tendu, lobé |
| Zone visée | premier poteau, deuxième poteau, point de penalty, retrait, hors surface |
| Nombre de joueurs dans la surface | 3 à 8 |
| Joueurs au retrait | 1 à 3 |
| Option courte | oui / non |
| Marquage adverse | zone, individuel, mixte |
| Gardien | sortir / rester / hésiter |

### Routines offensives

1. **Premier poteau** : déviation, but ou remise.
2. **Deuxième poteau** : tête décroisée.
3. **Point de penalty** : frappe directe.
4. **Retrait** : frappe de loin.
5. **Corner court** : combinaison, centre secondaire.
6. **Blocage** : écrans pour libérer un joueur.
7. **Deuxième ballon** : récupération hors surface.

### Défense

- **Zonale** : chaque joueur couvre une zone.
- **Individuelle** : un défenseur par attaquant.
- **Mixte** : les meilleurs de tête au marquage, les autres en zone.
- **Poteaux** : un joueur à chaque poteau (option).
- **Contre-attaque** : un attaquant reste haut.

### Événements produits

`corner_won`, `corner_taken`, `header`, `shot`, `goal`, `foul`, `counter`.

### Statistiques

Corners par équipe, buts sur corner, têtes gagnées, seconds ballons, taux de réussite.

## Coups francs

| Type | Distance | Options |
|---|---|---|
| Direct | 18–30 m | frappe, lob, puissance |
| Indirect | proche | combinaison, centre |
| Excentré | côté | centre, frappe |
| Mur | 2 à 6 joueurs | saut, mur avancé |

Routines : tir direct, une-deux, écran, centre au second poteau, ballon en retrait.

## Penalties

- Ordre des tireurs (1 à 5, puis mort subite).
- Niveau de pression (match, prolongation, séance).
- Choix du gardien (plongeon, attente).
- Rebond possible.
- Événements : `penalty_awarded`, `penalty_taken`, `penalty_saved`, `penalty_missed`.

## Touches et six mètres

- Touche : courte, longue, vers l'avant, sécurité.
- Six mètres : court, long, relance au sol.
- Ces phases influencent la possession et le pressing.

## Options / réglages

- Routines entraînées (1 à 3 par équipe).
- Tireurs désignés (corners gauche/droit, coups francs, penalties).
- Hauteur de la ligne défensive sur coup franc.
- Nombre de joueurs offensifs.
- Consignes du gardien.

## Modèle de données

```
set_piece_routines(id, team_id, type, side, name, delivery, target_zone, short_option)
set_piece_takers(id, team_id, type, player_id, priority)
match_set_pieces(id, match_id, minute, type, team_id, routine_id, outcome)
```

## MVP

1. Corners : centre vers une zone + tête.
2. Coups francs directs : mur + frappe.
3. Penalties : choix du tireur + gardien.
4. Statistiques de base.
5. Routines : plus tard.

## À ne pas copier

Ne pas reprendre les routines, animations ou données de FM. Concevoir ses propres routines
et les équilibrer par simulation.

## Approfondissement

### Sélection de routine

```text
si corner_gauche et tireur_gauche: routine = inswing
si adversaire grand: cibler second poteau
si peu de temps: option courte
sinon: routine par défaut
```

### Attribution du marquage

```text
trier les attaquants par jeu aérien
trier les défenseurs par jeu aérien
apparier les meilleurs
assigner les autres en zone
```

### Cas limites

- Tireur absent → changer de tireur.
- Gardien sorti → but facile.
- Contre-attaque → un attaquant reste haut.

### Critères de test

- Chaque corner produit un événement.
- Les stats de corners sont cohérentes.
- Aucun joueur ne reste sans consigne.
