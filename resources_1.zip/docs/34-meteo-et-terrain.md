# 34 — Météo et terrain

## Objectif

Faire varier les conditions sans rendre le jeu injuste.

## Météo

| Condition | Effet |
|---|---|
| Ensoleillé | condition normale |
| Nuageux | normale |
| Pluie | ballon rapide, contrôles difficiles |
| Forte pluie | visibilité, glissades |
| Neige | vitesse réduite, visibilité |
| Vent | centres et tirs |
| Chaleur | endurance |
| Froid | blessures musculaires |

## Terrain

| État | Effet |
|---|---|
| Parfait | normale |
| Sec | rebonds |
| Gras | jeu au sol |
| Détrempé | ralentissement |
| Gelé | glissades |
| Usé | irrégularités |

## Paramètres

- Type de pelouse (naturelle, hybride, synthétique).
- Drainage.
- Chauffage.
- Arrosage.
- Hauteur de tonte.

## Influence sur le jeu

- Vitesse du ballon.
- Rebond.
- Adhérence des crampons.
- Endurance.
- Précision des passes.
- Style de jeu (direct vs au sol).

## Modèle de données

```
weather(id, name, temperature, wind_speed, rain, snow)
pitch_conditions(id, stadium_id, grass_type, drainage, heating, condition)
match_conditions(match_id, weather_id, pitch_condition_id)
```

## MVP

1. Trois météos : normale, pluie, froid.
2. Effet sur la vitesse du ballon.
3. Effet sur l'endurance.
4. Puis neige, vent, terrain, arrosage.

## Équilibrage

- Les effets doivent être **lisibles** (icône, commentaire).
- Ne jamais décider du résultat à la place des joueurs.
- Une météo extrême doit être rare.

## Approfondissement

### Multiplicateurs

| Condition | Vitesse ballon | Endurance |
|---|---|---|
| Pluie | +5 % | −5 % |
| Neige | −10 % | −15 % |
| Chaleur | 0 | −15 % |
| Vent | ±10 % | 0 |

### Terrain

```text
adherence = base - usure
rebond = base + secheresse
```

### Cas limites

- Match sous la neige → visibilité.
- Terrain gelé → glissades.
- Vent fort → centres.

### Critères de test

- Les effets sont visibles.
- Aucune condition ne décide seule du résultat.
- Les conditions extrêmes sont rares.
