# 12 — Présentation 2D et 3D

## Objectif

Afficher un match compréhensible, fluide et paramétrable, sans mélanger rendu et simulation.

## Deux modes

| Mode | Contenu | Coût |
|---|---|---|
| **2D** | terrain vu du dessus, points/icônes, ballon | faible |
| **3D** | modèles, animations, caméras, stade, foule | élevé |

Les deux modes lisent **le même état de simulation**. On peut basculer en cours de match.

## Architecture

```
Simulation (ticks fixes)
   └─ état + événements
        ├─ Présentation 2D (interpolation, icônes)
        └─ Présentation 3D (interpolation, modèles, caméras)
```

Règles :

- La simulation ne connaît pas la caméra.
- Le rendu ne décide jamais d'une passe ou d'un tir.
- Les événements (but, carton, remplacement) sont diffusés via une file.

## Caméras 3D

| Caméra | Usage |
|---|---|
| TV / diffusion | vue principale |
| Tactique | vue haute, lecture des lignes |
| Poursuite | action rapprochée |
| But / ralenti | événement |
| Banc / tunnel | cinématique |

Transitions douces, jamais de coupure brutale.

## Modes de diffusion

- Match complet
- Moments clés uniquement
- Résumé étendu
- Résultat instantané (simulation sans rendu)
- Rejouer / ralenti

Ces modes sont des **filtres** sur le flux d'événements, pas des moteurs différents.

## Options

| Option | Valeur |
|---|---|
| Vitesse | lente, normale, rapide |
| Mode | 2D, 3D |
| Caméra | TV, tactique, poursuite |
| Commentaires | on/off, langue |
| Replays | on/off |
| Interface | minimale, complète |
| Météo | on/off |
| Moment | jour/nuit |

## 3D : briques

1. Terrain à l'échelle (105 × 68 m).
2. Joueurs : modèle + squelette + LOD.
3. Animations : locomotion, passe, tir, tacle, gardien.
4. Ballon : gravité, rebond, effet.
5. Stade : tribunes, sièges, panneaux.
6. Foule : impostors / instancing.
7. Éclairage : soleil + ombres bakées.
8. Interface : score, temps, événements.

## Performance

- LOD et culling.
- Foule en sprites.
- Ombres bakées.
- Textures streamées.
- Interpolation entre ticks.
- Pas de simulation de cheveux.

## 2D : bonnes pratiques

- Icônes lisibles avant tout.
- Couleurs par équipe + numéro.
- Ballon toujours visible.
- Flèches de course optionnelles.
- Zoom et déplacement.

## MVP

1. Terrain 2D + 22 points + ballon.
2. Caméra 3D fixe + 22 capsules.
3. Animations de course.
4. Score et chrono.
5. Événements affichés.
6. Puis : stade, foule, replays, cutscenes.

## Référence FM26 (observée)

Unity 6 + URP, Addressables (293 bundles, 3,85 Go), 33 bundles de personnages, `match-scene`,
`match-crowd`, `match-cutscenes`, `sianim` pour les animations. Voir la doc 02.

## À ne pas copier

Ne pas extraire les modèles, animations ou shaders de FM. Utiliser des assets CC0 ou créer
les siens ; s'inspirer de l'**architecture**, pas des fichiers.

## Approfondissement

### Machine à états de caméra

```text
TV → ACTION → REPLAY → TV
TV → TACTIQUE → TV
TV → BUT → CELEBRATION → TV
```

### Interpolation

```text
position_affichee = lerp(etat_tick_precedent, etat_tick_courant, alpha)
```

- `alpha` dépend du temps depuis le dernier tick.
- Ne jamais interpoler les décisions.
- Les événements sont affichés au tick, pas au milieu.

### Modes de diffusion

| Mode | Filtre |
|---|---|
| Complet | tous |
| Moments clés | priorité ≥ haute |
| Résumé | priorité ≥ moyenne |
| Instantané | aucun rendu |

### Critères de test

- Pas de téléportation visuelle.
- Le changement 2D/3D conserve l'état.
- Le replay ne modifie pas le score.
