# 42 — IA de match

## Objectif

Faire prendre des décisions crédibles aux 22 joueurs, sans script rigide.

## Boucle de décision

```
perception → évaluation → choix → action → conséquence
```

- **Perception** : ballon, coéquipiers, adversaires, espace.
- **Évaluation** : options et utilité.
- **Choix** : meilleure option + bruit.
- **Action** : passe, tir, course, tacle.
- **Conséquence** : mise à jour de l'état.

## Comportements

| Phase | Comportement |
|---|---|
| Possession | soutien, appel, largeur, profondeur |
| Transition offensive | contre-attaque, jeu direct |
| Transition défensive | repli, pressing |
| Défense | marquage, couverture, ligne |
| Coups de pied arrêtés | routines (doc 13) |

## Rôles

Chaque rôle définit :

- zone de base ;
- consignes ;
- priorités ;
- contraintes.

Exemple : un ailier reste large en possession, rentre intérieur en transition.

## Techniques d'IA

| Technique | Usage |
|---|---|
| Utility AI | noter les options |
| Behavior tree | séquences d'actions |
| GOAP | planification |
| State machine | états simples |
| Flocking | déplacements collectifs |

Recommandation pour un MVP : **utility AI** + state machine.

## Déterminisme

- Ticks fixes.
- RNG avec graine.
- Même graine = même match.
- Indispensable pour tester et rejouer.

## Équilibrage

- Éviter les décisions parfaites.
- Ajouter du bruit selon les attributs.
- Punir les mauvais choix, pas les joueurs.
- Vérifier que les rôles produisent des statistiques cohérentes.

## Modèle de données

```
ai_profiles(id, role_id, weights_json, noise)
match_decisions(id, match_id, player_id, tick, options_json, chosen, outcome)
```

## MVP

1. 22 joueurs avec rôle et position.
2. Passe, tir, course.
3. Pressing simple.
4. Repli.
5. Puis transitions, couvertures, coups de pied arrêtés.

## Piège

Une IA qui voit tout est impossible à battre. Une IA qui ne voit rien est frustrante. Le bon
équilibre est **l'information partielle**.

## Approfondissement

### Score d'utilité

```text
score(action) = gain_attaque - risque + preference_role
choisir max(score) avec bruit
```

### Boucle

```text
percevoir → lister options → scorer → choisir → exécuter
```

### Comportements

- Soutien.
- Appel.
- Pressing.
- Repli.
- Couverture.

### Cas limites

- Ballon inaccessible.
- Joueur fatigué.
- Infériorité numérique.

### Critères de test

- Les joueurs ne restent pas immobiles.
- Le pressing est cohérent.
- Aucune décision impossible.
