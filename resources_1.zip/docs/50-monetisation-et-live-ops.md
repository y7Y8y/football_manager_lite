# 50 — Monétisation et live ops

## Objectif

Documenter les modèles possibles sans casser l'équilibre ni la confiance.

## Modèles

| Modèle | Avantage | Risque |
|---|---|---|
| Achat unique | simple, respecté | pas de revenus récurrents |
| DLC de contenu | finance la suite | découpage abusif |
| Cosmétique | non pay-to-win | faible revenu |
| Abonnement | revenus stables | barrière |
| Pass de saison | engagement | pression |
| Loot boxes | revenus | réglementation, éthique |

## Règles

- **Jamais de pay-to-win** en solo.
- Aucun avantage compétitif payant en multijoueur.
- Les probabilités des loot boxes sont affichées.
- Les achats sont optionnels et clairs.
- Pas de pression temporelle artificielle.

## Live ops

| Événement | Fréquence |
|---|---|
| Mise à jour de données | après le mercato |
| Correctifs | à la demande |
| Défi saisonnier | mensuel |
| Contenu cosmétique | trimestriel |

## Modèle de données

```
products(id, name, type, price, currency)
entitlements(user_id, product_id, granted_at)
live_events(id, name, start, end, config_json)
```

## Indicateurs

- Conversion.
- Rétention.
- Revenu par joueur.
- Taux de remboursement.
- Satisfaction.

## MVP

1. Achat unique.
2. Aucun système de paiement complexe.
3. Puis cosmétiques.
4. Puis DLC.

## Légalité

- Affichage des prix TTC.
- Droit de rétractation selon le pays.
- Protection des mineurs.
- Loot boxes : vérifier la réglementation locale.

## Critères de test

- Aucun contenu payant ne bloque la progression.
- Les achats sont restore-ables.
- Les prix sont corrects.
