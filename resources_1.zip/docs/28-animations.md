# 28 — Animations

## Objectif

Animer 22 joueurs, un ballon, un gardien et une foule de façon lisible et fluide.

## Base technique

| Élément | Rôle |
|---|---|
| Squelette | os + hiérarchie |
| Skinning | attachement du mesh aux os |
| Clip | animation unitaire |
| State machine | états et transitions |
| Blend tree | mélange de clips |
| IK | adaptation au sol et au ballon |
| Root motion | déplacement porté par l'animation |

## Locomotion

- 8 directions (avant, arrière, gauche, droite, diagonales).
- 3 allures : marche, course, sprint.
- Transitions : démarrage, arrêt, virage.
- Mélange par vitesse et direction.
- Pieds au sol via IK.

## Actions

| Action | Clip |
|---|---|
| Passe | courte, longue, en profondeur |
| Tir | frappe, lob, volée |
| Tacle | debout, glissé |
| Duel | aérien, épaule |
| Gardien | plongeon, sortie, relance |
| Célébration | but, victoire |

## Blend et couches

- **Layer** : haut du corps (tir) + bas (course).
- **Additive** : fatigue, blessure, regard.
- **Masque** : bras, tête, jambes.
- **Sync** : garder le rythme entre clips.

## IK

- Pieds : adaptation au terrain.
- Mains : contact ballon.
- Tête : regard vers le ballon.
- Corps : éviter les interpénétrations.

## Événements d'animation

`footstep`, `ball_contact`, `tackle_contact`, `whistle`, `crowd_reaction`.

Ces événements déclenchent le son et les effets.

## Foule

- Pas de squelettes individuels.
- Impostors + animation de masse (vagues, sauts).
- Variation par tribune.
- LOD agressif.

## Performance

| Levier | Effet |
|---|---|
| Compression des clips | mémoire |
| GPU skinning | CPU |
| LOD d'animation | moins de mises à jour |
| Instancing | foule |
| Update à distance | CPU |
| Nombre d'os | budget |

## Référence FM26 (observée)

`sianim` : squelettes JSON (`skeleton.json`, `player_m`, `manager_*`, `crowd`), animations
`.cat`/`.amd`, locomotion homme/femme, `pack.cat` 28 Mo.

## MVP

1. Idle, course, sprint.
2. Passe, tir, tacle.
3. Blend course → sprint.
4. IK pieds.
5. Puis couches, gardien, célébrations, foule.

## Piège

Une animation belle mais mal synchronisée avec la simulation casse l'illusion. La priorité
est la **cohérence temporelle**, pas le réalisme.

## Approfondissement

### Machine à états

```text
Idle → Run → Sprint → Shoot → Idle
Run → Tackle → Recover → Run
Idle → Pass → Run
```

### Poids de blend

```text
poids_course = vitesse / vitesse_max
poids_sprint = max(0, (vitesse - seuil) / (max - seuil))
```

### IK pieds

```text
hauteur_pied = terrain(x, y) + offset
os_pied = cible IK
```

### Événements

- `footstep` pour le son.
- `ball_contact` pour l'effet.
- `tackle_contact` pour la collision.

### Cas limites

- Animation interrompue par un événement.
- Transition trop rapide → glissement.
- Joueur au sol → animation dédiée.

### Critères de test

- Pas de pied qui traverse le sol.
- Pas de glissement visible en virage.
- Les événements sonores sont synchronisés.
