# 07 — Priorité de chargement des assets

## Le fichier clé

`special folders.xml` déclare les racines de ressources. Extrait :

```xml
<record path="{$DATA}/game_simulation" resource_root="true" name="app_data_folder" />
<record path="{$SHARED_DATA}/database" name="database_folder" />
<record path="{$SHARED_DATA}/sicomps" name="comps_folder" />
<record path="{$SHARED_DATA}/editor" resource_root="true" name="editor_folder" />
<record path="{$SHARED_DATA}/sianim" resource_root="true" name="sianim_folder" />
<record path="{$SHARED_DATA}/simatch" resource_root="true" name="match_folder" />
<record path="{$SHARED_DATA}/simatchshared" resource_root="true" name="simatchshared_folder" />
<record path="{$SHARED_DATA}/shared/tables" resource_root="true" name="tables_folder" />
```

Commentaire du fichier :

> « Assets in earlier roots override those in later roots. »

## Deux mécanismes

### A. Resource Manager SI

Ordre de priorité :

1. Racines déclarées **en premier**
2. Racines suivantes
3. Contenu intégré

Le dossier utilisateur (`Documents\Sports Interactive\Football Manager 26\`) est enregistré
par l'application au démarrage ; il n'apparaît pas dans ce fichier mais il est prioritaire
pour les graphiques.

### B. Addressables Unity

- `aa/catalog.bin` + `settings.json` : catalogue principal
- `LicensedData/Core/catalog_info.bin` : catalogue licencié
- Résolution par **clé d'asset** (UID)

## Chaîne de résolution d'un écusson

```
1. Pack utilisateur        Documents\...\graphics\logos\<pack>\config.xml
2. Bundle licencié         LicensedData\...\club-<pays>
3. Bundle générique        club-default
4. Asset intégré Unity     aa\graphics
```

Le premier trouvé gagne.

## Conséquences

- Ajouter un pack ne modifie aucun fichier du jeu.
- Supprimer un pack restaure les visuels d'origine.
- Un `config.xml` invalide fait ignorer le pack.
- **Recharger le skin** applique les changements (sauf certains assets 3D).
- Les mises à jour du jeu ne touchent pas les packs utilisateur.

## Dossiers utilisateur

```
Documents\Sports Interactive\Football Manager 26\
├─ graphics\  (logos\, kits\ 2d\ 3d\, faces\)
├─ editor data\
├─ games\
├─ skins\
├─ tactics\
├─ matches\
└─ languages\
```

## Zones non vérifiées

- Ordre exact d'enregistrement des racines utilisateur.
- Gestion des collisions entre deux packs (hypothèse : dernier chargé gagnant).
- Comportement si un bundle est corrompu.

## Approfondissement

### Algorithme de résolution

```text
fonction resoudre(cle):
    pour chaque racine dans ordre_priorite:
        si racine.contient(cle): retourner racine.lire(cle)
    retourner absent
```

`ordre_priorite` = utilisateur, licencié, générique, intégré.

### Conflits

| Cas | Résultat attendu |
|---|---|
| Pack utilisateur + bundle | pack utilisateur |
| Deux packs utilisateur | dernier chargé (à confirmer) |
| Bundle licencié + default | licencié |
| Asset absent partout | placeholder |

### Invalidation

- Rechargement du skin.
- Changement de résolution.
- Mise à jour du jeu.

### Critères de test

- Un pack ajouté est visible après rechargement.
- Un pack supprimé restaure le visuel d'origine.
- Aucun crash si un pack est incomplet.
