# 24 — Recrutement et staff

## Scouting

| Étape | Détail |
|---|---|
| Mission | pays, compétition, poste, âge |
| Connaissance | 0–100 par pays |
| Rapport | points forts, faibles, potentiel estimé |
| Incertitude | plus le scout est mauvais, plus l'estimation est floue |

Un joueur non scouté n'affiche pas ses attributs réels : seulement une fourchette.

## Types de recrutement

- Joueurs confirmés.
- Jeunes à potentiel.
- Joueurs libres.
- Prêts.
- Recrutement interne (académie).

## Staff

| Rôle | Compétence clé |
|---|---|
| Entraîneur adjoint | tactique, motivation |
| Entraîneurs | technique, physique, mental |
| Préparateur physique | condition |
| Médecin / kiné | récupération |
| Scout | détection |
| Analyste | données |
| Responsable centre | jeunesse |
| Directeur sportif | transferts |

## Attributs

- Technique, mental, physique (pour les joueurs).
- Pour le staff : niveau, potentiel, spécialité, personnalité.
- Réputation et salaire.

## Embauche / licenciement

- Offre de contrat (durée, salaire).
- Le staff peut refuser selon réputation et projet.
- Licenciement = coût immédiat.

## Modèle de données

```
staff(id, name, role, attributes, reputation, club_id, contract_end)
scouting_assignments(id, club_id, scout_id, country_id, position, age_max, status)
scout_reports(id, assignment_id, player_id, rating, strengths, weaknesses, potential_range)
```

## MVP

1. 3 scouts, 3 pays.
2. Rapport avec fourchette de potentiel.
3. Embauche simple.
4. Puis missions avancées, analystes, réseau.

## Bonnes pratiques

- L'incertitude est ce qui rend le scouting intéressant.
- Ne pas révéler le PA exact.
- Les bons scouts coûtent cher.

## Approfondissement

### Connaissance d'un pays

```text
connaissance += missions * 5
connaissance -= temps_sans_mission * 1
connaissance = clamp(connaissance, 0, 100)
```

### Génération d'un rapport

```text
incertitude = 100 - scout_skill
fourchette = PA ± incertitude * 0.3
```

- Les attributs sont masqués si la connaissance est faible.
- Le rapport doit toujours mentionner les points faibles.
- Un bon scout réduit l'incertitude.

### Cas limites

- Joueur jamais scouté → fiche vide.
- Scout incompétent → fourchette très large.
- Joueur transféré → rapport obsolète.

### Critères de test

- Le PA exact n'est jamais affiché.
- Une mission produit un rapport.
- L'embauche respecte le budget staff.
