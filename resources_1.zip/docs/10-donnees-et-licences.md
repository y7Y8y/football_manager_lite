# 10 — Données, licences et stratégie d'assets

## Objectif

Savoir quelles données sont utilisables, lesquelles ne le sont pas, et comment construire
une base de développement sans bloquer le projet.

## Principe

Un jeu de gestion peut être **inspiré** de FM sans copier ses fichiers. Les mécaniques ne
sont pas protégées ; les assets, la base et l'interface le sont.

## Ce qui est protégé

| Élément | Protection |
|---|---|
| Logos de clubs et compétitions | marques déposées |
| Photos de joueurs | droit à l'image + droit d'auteur du photographe |
| Maillots | marques, sponsors, dessins |
| Base de données FM | droit d'auteur + droit sui generis (UE) + EULA |
| Code et moteur | droit d'auteur |
| Interface et écrans | droit d'auteur / design |

## Sources légales

| Besoin | Source | Licence / condition |
|---|---|---|
| Noms, dates, nationalités | Wikidata | CC0 |
| Clubs, compétitions, résultats | football-data.org | gratuit limité |
| Équipes, joueurs, logos | TheSportsDB | gratuit / premium |
| Données détaillées | API-Football, Sportmonks | payant, selon contrat |
| Statistiques avancées | FBref, StatsBomb Open Data | selon licence du dataset |
| Visages | génération synthétique | aucune droit tiers |
| Logos | création interne ou fournisseur | licence écrite |
| Photos | fournisseur ou photographe | licence écrite |

> Vérifier **la licence de chaque dataset** avant intégration : « gratuit » ne veut pas dire
> « libre de redistribution ».

## Stratégie recommandée

### Phase 1 — Développement

- Base **fictive** : 2 ligues, 20 clubs, 500 joueurs inventés.
- Logos **générés** (initiales, formes, couleurs).
- Visages **générés** (avatars).
- Aucun asset de FM.

Avantage : toutes les fonctionnalités sont codables, testables et publiables.

### Phase 2 — Contenu réel

- Brancher un fournisseur sous licence.
- Remplacer les fichiers, pas le code.
- Conserver une trace de chaque licence.

### Phase 3 — Publication

- Vérifier les contrats (territoire, durée, usage commercial).
- Prévoir une procédure de retrait si un ayant droit le demande.

## Bibliothèque d'assets

```
assets/
├─ players/<id>/portrait.webp + meta.json
├─ clubs/<id>/logo.webp + meta.json
├─ kits/<id>/home.webp, away.webp, third.webp
└─ licenses.csv
```

`licenses.csv` :

```csv
asset_id,type,file,source,license,author,url,date
p0001,portrait,portrait.webp,generated,CC0,internal,,2026-10-17
c0001,logo,logo.webp,provider,contract-x,provider,https://...,2026-10-17
```

## Règles pour l'équipe

1. **Aucun asset sans ligne dans `licenses.csv`.**
2. **Aucun fichier de FM** dans le repo ni dans le build.
3. Les placeholders doivent être **visuellement distincts** des assets réels.
4. Les captures d'écran de FM ne doivent pas servir de maquette publiée.
5. En cas de doute : remplacer par un placeholder.

## Ce que la doc peut décrire

- Les formats et l'architecture (docs 01 à 08).
- Les mécaniques de jeu (docs 11 à 24).
- Les modèles de données (doc 25).

## Ce qu'elle ne fournit pas

- Aucun logo, photo, maillot, modèle 3D ou base réelle.
- Aucun moyen d'extraire les assets du jeu.
- Aucun lien de téléchargement.

## Checklist avant publication

- [ ] Base fictive ou données sous licence vérifiée
- [ ] `licenses.csv` complet
- [ ] Aucun asset de FM
- [ ] Aucune capture d'écran de FM
- [ ] Mention « inspiré de, non affilié »
- [ ] Procédure de retrait prévue

## Approfondissement

### Matrice de sélection d'une source

| Critère | Poids |
|---|---|
| Licence compatible | obligatoire |
| Couverture | 3 |
| Fraîcheur | 3 |
| Coût | 2 |
| Facilité d'intégration | 2 |
| Stabilité de l'API | 3 |

### Validation d'un dataset

- Champs obligatoires présents.
- Identifiants uniques.
- Dates cohérentes.
- Doublons détectés.
- Licence documentée.

### Cas limites

- API qui interdit le cache → ne pas stocker.
- Dataset sans licence → ne pas utiliser.
- Données personnelles → minimiser.

### Critères de test

- Import reproductible.
- Rapport d'erreurs lisible.
- Aucun asset sans licence.
