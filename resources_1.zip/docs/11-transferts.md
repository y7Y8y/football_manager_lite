# 11 — Transferts et prêts

## Objectif

Décrire le cycle complet d'un transfert : détection, négociation, contrat, enregistrement.

## Les 3 acteurs

1. **Club vendeur** : fixe un prix, peut refuser.
2. **Club acheteur** : propose une structure de paiement.
3. **Joueur + agent** : négocient le contrat de travail.

Un transfert = **deux accords** + **une validation** (ligue).

## Fenêtres

| Période | Ouverture | Particularité |
|---|---|---|
| Été | juin → septembre | fenêtre principale |
| Hiver | janvier | plus courte |
| Hors fenêtre | reste de l'année | joueurs libres uniquement, pas d'enregistrement classique |

Les dates dépendent du pays et sont stockées en base, pas codées en dur.

## Types

| Type | Indemnité | Contrat |
|---|---|---|
| Permanent | oui | nouveau |
| Prêt | non (ou indemnité de prêt) | temporaire |
| Libre | non | nouveau |
| Échange | partielle | nouveau |
| Pré-contrat (Bosman) | non | commence à la fin du contrat |
| Jeune | indemnité de formation | premier contrat pro |

## Étapes

```
1. Repérage (scout)
2. Estimation de la valeur
3. Approche du club vendeur
4. Négociation de l'indemnité
5. Négociation du contrat joueur
6. Enregistrement (fenêtre, quotas, permis)
7. Visite médicale
8. Signature
```

### Valeur d'un joueur

Facteurs : niveau actuel, potentiel, âge, contrat restant, forme, réputation du club et du
championnat, besoin du vendeur, concurrence, clause libératoire.

Le vendeur affiche un **prix demandé** supérieur à la valeur. Une offre basse est refusée ou
contre-proposée.

### Structure d'une offre

| Élément | Effet |
|---|---|
| Montant fixe | payé immédiatement |
| Versements | étalés sur plusieurs années |
| Bonus d'apparitions | conditionnel |
| Bonus de buts | conditionnel |
| Sell-on | % de la revente future |
| Buy-back | droit de rachat |
| Échange | joueur + argent |

### Contrat joueur

Salaire, durée, primes (apparition, buts, titre), clause libératoire, statut d'effectif,
temps de jeu promis, prime d'agent, indemnité de signature.

Refus possible si : salaire trop bas, temps de jeu insuffisant, réputation du club, absence
de compétition européenne, meilleure offre ailleurs.

### Enregistrement

Échec possible si : fenêtre fermée, quota étranger, permis de travail refusé, limite de
joueurs enregistrés, règle homegrown, fair-play financier.

## Prêts

| Option | Effet |
|---|---|
| Contribution salariale | répartition du salaire |
| Indemnité de prêt | versée au club d'origine |
| Option d'achat | droit d'acheter |
| Obligation d'achat | achat automatique |
| Rappel | retour anticipé |

## Clauses

- **Release clause** : achat automatique au montant fixé.
- **Sell-on** : pourcentage de la revente.
- **Buy-back** : rachat à prix convenu.
- **Bonus conditionnels** : paiements sur événements.
- **Option / obligation d'achat** : prêt.

## IA des clubs

L'IA achète selon : budget, masse salariale, besoins par poste, âge/potentiel, réputation,
fenêtre, prix demandé. Elle vend si : effectif trop gros, joueur mécontent, fin de contrat,
besoin d'argent, offre supérieure à la valeur.

## Modèle de données

```
clubs(id, name, reputation, budget_transfer, budget_wage)
players(id, name, birthdate, ca, pa, value, club_id)
contracts(id, player_id, club_id, start, end, wage, release_clause, squad_status)
transfer_windows(id, country, opens, closes)
transfer_offers(id, player_id, from_club, to_club, fee, installments, clauses, status)
clauses(id, contract_id, type, value, percentage)
loans(id, player_id, from_club, to_club, start, end, wage_share, option_price)
registrations(id, player_id, club_id, league_id, date, homegrown)
```

## MVP

1. Fenêtres et enregistrement.
2. Valeur simple (âge, CA/PA, contrat restant, réputation).
3. Offre IA vs prix demandé.
4. Contrat (salaire, durée, temps de jeu).
5. Prêt avec option d'achat.
6. Refus si quota/permis/finances.

## À ne pas copier

Les formules exactes de FM ne sont pas publiques. Concevoir ses propres formules, documenter
les paramètres, et équilibrer par tests.

## Approfondissement

### Algorithme de négociation

```text
prix = valeur * facteur_age * facteur_contrat * facteur_forme * facteur_reputation
offre = budget_disponible * priorite_poste
si offre < prix * 0.7: refus
si offre < prix: contre-proposition
si offre >= prix: accepter l'indemnité
puis négocier le contrat joueur
```

### Facteurs indicatifs

| Facteur | Effet |
|---|---|
| Âge 21–27 | +20 % |
| Contrat < 1 an | −30 % |
| Fin de contrat | −80 % |
| Bonne forme | +10 % |
| Club riche | +15 % |

### Cas limites

- Joueur refuse le contrat → transfert annulé.
- Club n'a plus de budget → offre bloquée.
- Fenêtre fermée → accord possible, enregistrement refusé.
- Prêt avec obligation → impact budget futur.

### Critères de test

- Un transfert ne peut pas dépasser le budget.
- Un joueur libre ne coûte aucune indemnité.
- Une offre acceptée produit un contrat valide.
- Un prêt avec option crée une clause.
