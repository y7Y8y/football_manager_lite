# 40 — Statistiques et analytics

## Objectif

Transformer les événements en informations utiles pour le joueur et pour l'IA.

## Statistiques de base

| Stats | Calcul |
|---|---|
| Possession | temps de possession |
| Tirs | événements `shot` |
| Tirs cadrés | `shot_on_target` |
| Passes | `pass` |
| Précision | passes réussies / tentées |
| Corners | `corner` |
| Fautes | `foul` |
| Cartons | `yellow` / `red` |
| Distance | somme des déplacements |
| Sprints | vitesse > seuil |

## Statistiques avancées

- **xG** : probabilité de but par tir.
- **xA** : probabilité de passe décisive.
- **xT** : valeur de progression du ballon.
- **PPDA** : intensité du pressing.
- **Heatmaps** : zones occupées.
- **Pass maps** : réseaux de passes.
- **Progression** : passes vers l'avant.

## Calcul

Toujours **à partir des événements** :

```
events → agrégation → stats
```

Ne jamais calculer une stat en parallèle de la simulation.

## xG simplifié

```
xg = f(distance, angle, pied, pression, type de tir)
```

Formule à calibrer sur des données de test. L'important est la **cohérence**, pas la valeur
exacte.

## Data hub

- Filtres : équipe, joueur, période, compétition.
- Comparaisons.
- Tendances.
- Export CSV.

## Modèle de données

```
match_stats(match_id, team_id, possession, shots, shots_on_target, xg, passes, pass_accuracy)
player_match_stats(match_id, player_id, minutes, goals, assists, passes, rating, distance)
shot_events(id, match_id, player_id, x, y, xg, outcome)
```

## MVP

1. Possession, tirs, passes, corners, fautes.
2. Note de match.
3. xG simple.
4. Puis heatmaps, xA, PPDA, data hub.

## Piège

Une statistique mal expliquée est pire que pas de statistique. Toujours afficher la définition.

## Approfondissement

### xG simplifié

```text
xg = 1 / (1 + exp(-(a - b * distance - c * angle)))
```

- Calibrer `a`, `b`, `c` sur des tirs de test.
- Plafonner entre 0.01 et 0.99.

### Agrégation

```text
stats = reduce(events, par type et par équipe)
```

### Cas limites

- Tir contré.
- But contre son camp.
- Penalty.

### Critères de test

- Les stats correspondent aux événements.
- xG cohérent avec les buts sur une saison.
- Aucun doublon.
