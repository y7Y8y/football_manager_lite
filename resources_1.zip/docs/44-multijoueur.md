# 44 — Multijoueur

## Objectif

Permettre de jouer à plusieurs sans désynchronisation ni triche.

## Modes

| Mode | Principe | Complexité |
|---|---|---|
| Hotseat | plusieurs managers sur la même machine | faible |
| Asynchrone | chacun joue son tour quand il veut | moyenne |
| Temps réel | plusieurs managers en direct | élevée |
| Coopératif | deux managers dans le même club | élevée |

## Architecture recommandée

```
Client → Serveur autoritaire → État validé → Clients
```

- Le serveur valide les actions.
- Le client n'est jamais source de vérité.
- La simulation tourne côté serveur (ou en lockstep validé).
- Les sauvegardes sont serveur.

## Simulation déterministe

- Même graine = même résultat.
- Tick fixe.
- Aucune dépendance au framerate.
- Actions horodatées.

## Synchronisation

| Approche | Usage |
|---|---|
| Lockstep | match en direct |
| État complet | tour par tour |
| Delta | actions fréquentes |
| Replay | vérification |

## Tour par tour

```text
serveur → état du tour → client A agit → validation → client B agit → tick
```

- Un tour = une journée de jeu (ou une semaine).
- Les actions simultanées sont résolues dans un ordre déterministe.
- Le serveur peut imposer un délai maximum.

## Modèle de données

```
rooms(id, name, mode, status, created_at)
room_members(room_id, user_id, club_id, role)
room_turns(room_id, turn_number, started_at, ends_at)
room_actions(id, room_id, turn, user_id, action, payload, validated)
```

## Sécurité

- Authentification.
- Validation serveur de chaque action.
- Limitation de débit.
- Journal d'audit.

## MVP

1. Hotseat local.
2. Asynchrone avec sauvegarde partagée.
3. Puis serveur autoritaire.
4. Puis temps réel.

## Critères de test

- Deux clients voient le même score.
- Une action invalide est rejetée.
- Une déconnexion ne corrompt pas la partie.
