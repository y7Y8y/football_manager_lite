# 25 — Modèle de données

## Objectif

Fournir une base de schéma pour un jeu de management inspiré de FM, sans dépendre d'une
base existante.

## Vue d'ensemble

```mermaid
erDiagram
  COUNTRY ||--o{ COMPETITION : hosts
  COMPETITION ||--o{ SEASON : has
  SEASON ||--o{ FIXTURE : schedules
  CLUB ||--o{ PLAYER : employs
  CLUB ||--o{ CONTRACT : signs
  PLAYER ||--o{ CONTRACT : signs
  FIXTURE ||--o{ MATCH_EVENT : contains
  CLUB ||--o{ KIT : wears
  CLUB ||--o{ STAFF : employs
  PLAYER ||--o{ INJURY : suffers
  CLUB ||--o{ TRANSFER_OFFER : makes
  PLAYER ||--o{ TRANSFER_OFFER : receives
  CLUB ||--o{ ACADEMY : owns
  CLUB ||--o{ RIVALRY : plays
```

## Tables principales

### Référentiel

```
countries(id, name, code, reputation)
competitions(id, country_id, name, type, level, reputation)
competition_rules(id, competition_id, max_squad, foreign_limit,
                  homegrown_min, loan_limit, ffp_enabled)
seasons(id, competition_id, year, start_date, end_date)
```

### Clubs et effectifs

```
clubs(id, name, country_id, city, reputation, stadium_id,
      budget_transfer, budget_wage, primary_color, secondary_color)
players(id, name, first_name, birthdate, nationality_id, position,
        ca, pa, value, club_id, squad_status, morale, fitness, sharpness)
contracts(id, player_id, club_id, start, end, wage, release_clause,
          option_year, squad_status)
staff(id, name, role, attributes_json, reputation, club_id, contract_end)
```

### Compétitions et matchs

```
fixtures(id, season_id, round, home_club_id, away_club_id, date, status,
         home_goals, away_goals)
match_events(id, match_id, minute, second, type, team_id, player_id,
             secondary_player_id, x, y, outcome, metadata)
match_stats(match_id, team_id, possession, shots, shots_on_target, xg,
            passes, pass_accuracy, corners, fouls, yellows, reds)
lineups(id, match_id, team_id, formation, player_id, position, role, duty, is_captain)
```

### Transferts

```
transfer_windows(id, country_id, opens, closes)
transfer_offers(id, player_id, from_club_id, to_club_id, fee, installments,
                clauses_json, status, created_at)
loans(id, player_id, from_club_id, to_club_id, start, end,
      wage_share, option_price, obligation)
registrations(id, player_id, club_id, league_id, date, homegrown)
```

### Tactique et entraînement

```
tactics(id, club_id, name, formation, mentality, pressing, tempo, width)
tactic_slots(tactic_id, position, role, duty, player_id)
tactic_familiarity(club_id, tactic_id, value)
training_programs(id, club_id, focus, intensity)
player_training(player_id, program_id, focus, intensity)
```

### Jeunesse

```
academies(club_id, facilities, recruitment, reputation, hoyd_staff_id)
youth_intakes(id, club_id, season, player_id, quality)
player_development(player_id, date, ca_before, ca_after, reason)
homegrown_status(player_id, club_id, since, status)
```

### Médical et finances

```
injuries(id, player_id, type, severity, start_date, expected_return,
         actual_return, context)
player_condition(player_id, fitness, sharpness, fatigue)
club_finances(club_id, season, revenue, costs, transfer_budget, wage_budget)
transactions(id, club_id, date, type, amount, description)
```

### Contexte

```
rivalries(club_a_id, club_b_id, intensity, origin)
fan_confidence(club_id, value, last_update)
board_expectations(club_id, season_id, objective, min_position, patience, confidence)
press_conferences(id, match_id, team_id, date, context)
press_questions(id, conference_id, theme, journalist_id, text)
press_answers(id, question_id, tone, text)
kits(id, club_id, season, type, primary_color, secondary_color, pattern)
kit_assignments(match_id, club_id, kit_id)
```

## Conventions

- Clés primaires entières ou UUID.
- Dates ISO 8601 (`YYYY-MM-DD`).
- Attributs 0–100 sauf `ca`, `pa`, `value` (entiers ou montants).
- Montants en unités entières (centimes ou milliers) pour éviter les flottants.
- `metadata` / `attributes_json` pour les champs variables sans migration.
- Un événement de match est **immuable**.

## Sous-ensemble MVP

Minimum pour une première boucle jouable :

```
countries, competitions, seasons, clubs, players, contracts,
fixtures, match_events, match_stats, lineups, tactics, tactic_slots,
transfer_offers, injuries, club_finances
```

## Pièges

- Ne pas stocker le classement en dur : le calculer depuis les matchs.
- Ne pas dupliquer le nom du club dans les événements : utiliser `club_id`.
- Ne pas mettre les attributs de jeu dans `players` si le nombre explose : table dédiée.
- Ne pas utiliser de flottants pour l'argent.

## Approfondissement

### Normalisation

- Une entité = une table.
- Pas de listes dans une colonne (sauf JSON documenté).
- Clés étrangères explicites.
- Pas de doublons de noms.

### Index recommandés

| Table | Index |
|---|---|
| players | `club_id`, `nationality_id` |
| fixtures | `season_id`, `date` |
| match_events | `match_id`, `minute` |
| transfer_offers | `player_id`, `status` |

### Migrations

```text
schema_version=1 → migration_2 → schema_version=2
```

- Une migration = une transaction.
- Sauvegarde avant migration.
- Migration testée sur une sauvegarde réelle.

### Critères de test

- Le schéma se crée sur une base vide.
- Les contraintes empêchent les références orphelines.
- Une migration conserve les données.
