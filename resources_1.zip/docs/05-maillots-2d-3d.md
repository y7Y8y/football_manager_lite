# 05 — Maillots 2D et 3D

## Deux représentations

| Type | Bundles | Taille | Usage |
|---|---|---|---|
| `kits2d-*` | 70 | 49,5 Mo | Sprites 2D (fiches, sélection, UI) |
| `kits3d-*` | 64 | 115,7 Mo | Textures/matériaux sur le modèle 3D |

Les deux jeux sont **indépendants** : un pays peut avoir l'un sans l'autre.

## Ressources complémentaires

| Bundle | Rôle |
|---|---|
| `kits2d-outfield` | Gabarits joueurs de champ |
| `kits2d-goalkeeper` | Gabarits gardiens |
| `kits2d-numbers` | Numéros |
| `kits2d-shorts` / `kits2d-socks` | Shorts et chaussettes |
| `kits2d-nations` | Sélections |
| `sleeves-3d` | Manches 3D |
| `art-characters-kitresources` | Application du maillot |
| `kitnumber` | Numéros 3D |

## Couverture

| Groupe | Pays / variantes |
|---|---|
| `Core` (3D) | ARG, AUS (+F), BEL, CAN, CRO, CZE, DEN (+F), ENG (+F), FRA, GER (+F), GIB, ITA (+F), JPN (+F), KOR, LAT, LIT, NED, NIR, POL, POR, SCO, SWE (F), UAE, USA (+F), WAL (+F) |
| `Core` (2D) | mêmes pays + `eng_nl` (National League), `fmfc`, `default`, `default_w` |
| `Extra` | compléments : ARG, AUS, BEL, CAN, CRO, CZE, DEN (+F), ENG (+F), `eng_nl`, FRA, GER (+F), GIB, ITA, JPN, KOR, LAT, LIT, MEX (+F), NED, NIR, POL, POR, SCO, SWE (F), UAE, USA, WAL (+F) |

**Non couverts** : Espagne, Brésil, Turquie, Russie, Ukraine, Grèce, Suisse, Autriche,
Norvège, etc.

## Comment un maillot est choisi

1. La **base** associe club, style et saison.
2. Le jeu résout un **kit 2D** (UI) et un **kit 3D** (match).
3. Le kit 3D est appliqué via `art-characters-kitresources`.
4. Numéros et manches sont des ressources séparées.

Un maillot n'est pas une image unique : c'est un **ensemble de textures**.

## Surcharge utilisateur

```
Documents\Sports Interactive\Football Manager 26\graphics\kits\
├─ 2d\  (config.xml + *.png)
└─ 3d\  (config.xml + *.png)
```

- Kits 2D : mapping par UID.
- Kits 3D : textures référencées dans `config.xml`.
- Recharger le skin après installation.

## Points techniques

- Textures compressées dans les bundles.
- Variantes `_w` = équipes féminines.
- `eng_nl` = ligue (National League), pas un pays.
- `fmfc` = contenu fictif.

## Légalité

Maillots protégés (marques, sponsors). Ce dépôt ne contient aucune texture.

## Approfondissement

### Détection de conflit de couleurs

```text
distance = delta_e(couleur_domicile, couleur_exterieur)
si distance < seuil:
    equipe_exterieur_change
si distance(arbitre, equipe) < seuil:
    arbitre_change
```

- Utiliser l'espace Lab pour une distance perceptuelle.
- Priorité au club à domicile.
- Vérifier aussi le gardien.

### Textures 3D

| Canal | Contenu |
|---|---|
| Albedo | couleurs, motifs, sponsors |
| Normal | plis du tissu |
| Roughness | brillance |
| Métallic | détails |

### Saisons

- Un kit par saison et par type.
- Conservation possible si le club ne change pas.
- Archivage pour l'historique.

### Cas limites

- Sponsor interdit dans certaines compétitions.
- Couleurs identiques en coupe → third.
- Maillot 2D absent mais 3D présent.

### Critères de test

- Aucun match avec deux maillots identiques.
- L'arbitre reste distinguable.
- Le kit 3D s'applique sans déformer le modèle.
