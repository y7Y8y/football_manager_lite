# 35 — Stades et environnement

## Objectif

Créer un lieu crédible, performant et reconnaissable.

## Stade

| Élément | Détail |
|---|---|
| Capacité | places assises/debout |
| Tribunes | 4 côtés, angles |
| Toit | couverture, ombre |
| Pelouse | dimensions, orientation |
| Éclairage | projecteurs |
| Panneaux | publicité |
| Écran | score |
| Tunnels | entrée des joueurs |

## Foule

- Densité selon affluence.
- Impostors + instancing.
- Animation de masse (vagues, tifos).
- Réactions aux événements.
- Couleurs par club.

## Environnement

- Ville / quartier.
- Parkings, abords.
- Centre d'entraînement.
- Centre de formation.
- Boutique / musée (option).

## Personnalisation

- Couleurs des sièges.
- Tifos.
- Chants.
- Écrans.
- Publicité (avec licences).

## Performance

- Modèle unique + variantes.
- Pas de sièges individuels détaillés au loin.
- Ombres bakées.
- Pas de foule animée en 3D complète.

## Modèle de données

```
stadiums(id, name, capacity, city, country_id, pitch_length, pitch_width)
stands(stadium_id, side, capacity, roof)
stadium_assets(stadium_id, type, file)
attendance(match_id, club_id, tickets_sold, capacity)
```

## MVP

1. Un stade générique.
2. Quatre tribunes.
3. Foule en sprites.
4. Panneaux et score.
5. Puis variantes, tifos, environnement.

## Référence FM26 (observée)

`stadiums-models` 189 Mo, `art-stadiums-pitch` 138 Mo, `stadiums-seats`, `stadium-ads`,
`tifo`, `art-lighting-skies` (47 bundles).

## Piège

Un stade trop détaillé coûte plus cher que 22 joueurs. Prioriser la lisibilité du match.

## Approfondissement

### Affluence

```text
affluence = capacite * taux_remplissage
taux = f(reputation, resultats, rivalite, prix)
```

### Modèle 3D

- Un stade = un mesh + des variantes de tribunes.
- Sièges en instancing.
- Foule en impostors.
- Panneaux en textures.

### Cas limites

- Capacité dépassée.
- Travaux.
- Stade neutre.

### Critères de test

- 60 fps avec foule pleine.
- Affluence cohérente avec les finances.
- Aucun trou visible dans les tribunes.
